"""Validated local chat data and bounded MLX-LM LoRA training commands."""

from __future__ import annotations

import hashlib
import json
import math
import random
import sys
from pathlib import Path

from zerolm.open_model import (
    DEFAULT_MODEL_ID,
    DEFAULT_MODEL_REVISION,
    default_model_snapshot_path,
)


def _validate_record(record: object, line_number: int) -> dict[str, object]:
    if not isinstance(record, dict) or not isinstance(record.get("messages"), list):
        raise ValueError(f"line {line_number}: expected a messages list")
    messages = record["messages"]
    if len(messages) < 2:
        raise ValueError(f"line {line_number}: expected user and assistant messages")
    roles: list[str] = []
    for message in messages:
        if not isinstance(message, dict):
            raise ValueError(f"line {line_number}: every message must be an object")
        role, content = message.get("role"), message.get("content")
        if role not in {"system", "user", "assistant"} or not isinstance(content, str) or not content.strip():
            raise ValueError(f"line {line_number}: invalid role or empty content")
        roles.append(role)
    conversational_roles = roles[1:] if roles[0] == "system" else roles
    if roles.count("system") > (1 if roles[0] == "system" else 0):
        raise ValueError(f"line {line_number}: system is allowed only as the first message")
    expected = ["user" if index % 2 == 0 else "assistant" for index in range(len(conversational_roles))]
    if conversational_roles != expected or conversational_roles[-1:] != ["assistant"]:
        raise ValueError(
            f"line {line_number}: chat must alternate user/assistant and end with assistant"
        )
    return record


def prepare_chat_dataset(
    source: str | Path,
    output_dir: str | Path,
    *,
    validation_count: int = 1,
    seed: int = 1337,
    data_license: str = "user-declared-local-data",
) -> dict[str, object]:
    """Validate and deterministically split local MLX-LM chat JSONL."""
    source_path = Path(source).expanduser().resolve()
    destination = Path(output_dir).expanduser().resolve()
    if destination.exists():
        raise FileExistsError(f"output directory already exists: {destination}")
    if not source_path.is_file():
        raise FileNotFoundError(f"source dataset does not exist: {source_path}")

    records = []
    fingerprints: set[str] = set()
    for line_number, line in enumerate(source_path.read_text(encoding="utf-8").splitlines(), 1):
        if line.strip():
            record = _validate_record(json.loads(line), line_number)
            fingerprint = json.dumps(record, ensure_ascii=False, sort_keys=True)
            if fingerprint in fingerprints:
                raise ValueError(f"line {line_number}: duplicate chat example")
            fingerprints.add(fingerprint)
            records.append(record)
    if not records:
        raise ValueError("source dataset must contain at least one example")
    if validation_count < 0 or validation_count >= len(records):
        raise ValueError("validation_count must leave at least one training example")

    random.Random(seed).shuffle(records)
    valid = records[:validation_count]
    training = records[validation_count:]
    destination.mkdir(parents=True)

    def write_jsonl(path: Path, values: list[dict[str, object]]) -> None:
        path.write_text(
            "".join(json.dumps(value, ensure_ascii=False) + "\n" for value in values),
            encoding="utf-8",
        )

    write_jsonl(destination / "train.jsonl", training)
    if valid:
        write_jsonl(destination / "valid.jsonl", valid)
    metadata = {
        "source": str(source_path),
        "source_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
        "training_examples": len(training),
        "validation_examples": len(valid),
        "seed": seed,
        "format": "mlx-lm-chat-jsonl",
        "data_license": data_license,
        "base_model": DEFAULT_MODEL_ID,
        "base_model_revision": DEFAULT_MODEL_REVISION,
        "base_model_license": "Apache-2.0",
    }
    (destination / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return metadata


def build_training_command(
    data_dir: str | Path,
    adapter_path: str | Path,
    *,
    model_id: str = DEFAULT_MODEL_ID,
    model_path: str | Path | None = None,
    iterations: int = 100,
    learning_rate: float = 1e-5,
    batch_size: int = 1,
    num_layers: int = 4,
) -> list[str]:
    """Build a conservative QLoRA command for a 24 GB unified-memory Mac."""
    if not 1 <= iterations <= 10_000:
        raise ValueError("iterations must be between 1 and 10000")
    if not 1 <= batch_size <= 2:
        raise ValueError("batch_size must be between 1 and 2")
    if not 1 <= num_layers <= 8:
        raise ValueError("num_layers must be between 1 and 8")
    if not math.isfinite(learning_rate) or not 1e-8 <= learning_rate <= 1e-2:
        raise ValueError("learning_rate must be finite and between 1e-8 and 1e-2")
    training_file = Path(data_dir).expanduser().resolve() / "train.jsonl"
    if not training_file.is_file():
        raise FileNotFoundError(f"prepared train.jsonl does not exist: {training_file}")
    if model_path is not None:
        selected_model = Path(model_path).expanduser().resolve()
        if not selected_model.is_dir():
            raise FileNotFoundError(f"model path does not exist: {selected_model}")
        model_argument = str(selected_model)
    elif model_id == DEFAULT_MODEL_ID:
        selected_model = default_model_snapshot_path()
        if not selected_model.is_dir():
            raise FileNotFoundError(
                "pinned model snapshot is not cached; run open-generate once before LoRA training"
            )
        model_argument = str(selected_model)
    else:
        model_argument = model_id
    return [
        sys.executable,
        "-m",
        "mlx_lm",
        "lora",
        "--model",
        model_argument,
        "--train",
        "--data",
        str(Path(data_dir).expanduser().resolve()),
        "--adapter-path",
        str(Path(adapter_path).expanduser().resolve()),
        "--iters",
        str(iterations),
        "--learning-rate",
        str(learning_rate),
        "--batch-size",
        str(batch_size),
        "--num-layers",
        str(num_layers),
        "--max-seq-length",
        "512",
        "--grad-checkpoint",
        "--mask-prompt",
    ]
