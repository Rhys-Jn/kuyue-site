"""Synthetic, exactly verifiable arithmetic data and evaluation helpers."""

from __future__ import annotations

import ast
import json
import random
import re
from dataclasses import asdict, dataclass
from fractions import Fraction
from pathlib import Path


_PLACE_NAMES = ("个位", "十位", "百位", "千位", "万位", "十万位")
_ANSWER_PATTERN = re.compile(r"(?:所以)?答案(?:是|：|:)\s*(-?\d+)")
_ADDITION_QUERY_PATTERN = re.compile(
    r"^\s*(?:请计算\s*)?([+-]?\d{1,6})\s*\+\s*([+-]?\d{1,6})\s*"
    r"(?:(?:等于|是)\s*(?:多少|几)|(?:多少|几))?\s*[=＝?？。]?\s*$"
)
_SIGN_TRANSLATION = str.maketrans(
    {
        "−": "-",
        "－": "-",
        "＋": "+",
        "×": "*",
        "＊": "*",
        "÷": "/",
        "／": "/",
        "（": "(",
        "）": ")",
        "＝": "=",
    }
)
_MAX_EXPRESSION_LENGTH = 100
_MAX_AST_NODES = 64
_MAX_INTERMEDIATE_MAGNITUDE = 10**18


class ArithmeticDomainError(ValueError):
    """Raised when a valid arithmetic expression has no defined result."""


@dataclass(frozen=True)
class ReasoningExample:
    prompt: str
    completion: str
    answer: str

    @property
    def text(self) -> str:
        return self.prompt + self.completion


def _validate_operand_width(*operands: int) -> None:
    if any(len(str(abs(operand))) > len(_PLACE_NAMES) for operand in operands):
        raise ValueError(f"operands may have at most {len(_PLACE_NAMES)} digits")


def _column_addition_steps(left: int, right: int) -> list[str]:
    width = max(len(str(left)), len(str(right)))
    carry = 0
    steps: list[str] = []
    for position in range(width):
        left_digit = left // (10**position) % 10
        right_digit = right // (10**position) % 10
        total = left_digit + right_digit + carry
        next_carry, written_digit = divmod(total, 10)
        steps.append(
            f"{_PLACE_NAMES[position]}：{left_digit}+{right_digit}+进位{carry}="
            f"{total}，写{written_digit}进{next_carry}"
        )
        carry = next_carry
    if carry:
        steps.append(f"最高位写进位{carry}")
    return steps


def _column_subtraction_steps(minuend: int, subtrahend: int) -> list[str]:
    if minuend < subtrahend or subtrahend < 0:
        raise ValueError("column subtraction requires minuend >= subtrahend >= 0")
    width = max(len(str(minuend)), len(str(subtrahend)))
    borrow = 0
    steps: list[str] = []
    for position in range(width):
        minuend_digit = minuend // (10**position) % 10
        subtrahend_digit = subtrahend // (10**position) % 10
        raw_difference = minuend_digit - subtrahend_digit - borrow
        if raw_difference < 0:
            written_digit = raw_difference + 10
            next_borrow = 1
            detail = (
                f"{_PLACE_NAMES[position]}：{minuend_digit}-{subtrahend_digit}"
                f"-借位{borrow}不够减，借1后={written_digit}，写{written_digit}借1"
            )
        else:
            written_digit = raw_difference
            next_borrow = 0
            detail = (
                f"{_PLACE_NAMES[position]}：{minuend_digit}-{subtrahend_digit}"
                f"-借位{borrow}={written_digit}，写{written_digit}借0"
            )
        steps.append(detail)
        borrow = next_borrow
    if borrow:
        raise RuntimeError("verified subtraction ended with an unresolved borrow")
    return steps


def addition_example(left: int, right: int) -> ReasoningExample:
    """Create a worked non-negative column-addition example."""
    if left < 0 or right < 0:
        raise ValueError("addition operands must be non-negative")
    _validate_operand_width(left, right)
    steps = _column_addition_steps(left, right)

    prompt = f"用户：请计算{left}+{right}。助手：推理："
    completion = "；".join(steps) + f"。所以答案是{left + right}。"
    return ReasoningExample(prompt=prompt, completion=completion, answer=str(left + right))


def signed_addition_example(left: int, right: int) -> ReasoningExample:
    """Solve signed addition using checked addition or subtraction by magnitude."""
    _validate_operand_width(left, right)
    result = left + right
    prompt = f"用户：请计算{left}+{right}。助手：推理："

    if left == 0 or right == 0:
        completion = f"零是加法单位元，不改变另一个加数。所以答案是{result}。"
    elif left > 0 and right > 0:
        return addition_example(left, right)
    elif left < 0 and right < 0:
        magnitude = abs(left) + abs(right)
        steps = "；".join(_column_addition_steps(abs(left), abs(right)))
        completion = (
            f"两个加数都为负，先计算绝对值之和。{steps}。"
            f"绝对值之和是{magnitude}，结果取负。所以答案是{result}。"
        )
    else:
        left_magnitude, right_magnitude = abs(left), abs(right)
        if left_magnitude == right_magnitude:
            completion = "两个加数符号相反且绝对值相同，互相抵消。所以答案是0。"
        else:
            larger = max(left_magnitude, right_magnitude)
            smaller = min(left_magnitude, right_magnitude)
            steps = "；".join(_column_subtraction_steps(larger, smaller))
            sign_rule = (
                "较大绝对值来自负数，结果取负"
                if result < 0
                else "较大绝对值来自正数，结果取正"
            )
            completion = (
                f"两个加数符号不同，转为绝对值相减：{larger}-{smaller}。"
                f"{steps}。差是{larger - smaller}，{sign_rule}。所以答案是{result}。"
            )
    return ReasoningExample(prompt=prompt, completion=completion, answer=str(result))


def solve_addition_query(query: str) -> ReasoningExample:
    """Parse a bounded addition query and solve it with checked column arithmetic."""
    normalized_query = query.translate(_SIGN_TRANSLATION)
    match = _ADDITION_QUERY_PATTERN.fullmatch(normalized_query)
    if match is None:
        raise ValueError("expected an addition expression such as 8+9")
    left, right = (int(value) for value in match.groups())
    return signed_addition_example(left, right)


def _format_fraction(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


def _checked_result(value: Fraction) -> Fraction:
    if (
        abs(value.numerator) > _MAX_INTERMEDIATE_MAGNITUDE
        or value.denominator > _MAX_INTERMEDIATE_MAGNITUDE
    ):
        raise ValueError("arithmetic result is too large")
    return value


def _evaluate_arithmetic_node(node: ast.AST) -> tuple[Fraction, list[str]]:
    if isinstance(node, ast.Constant):
        if type(node.value) is not int:
            raise ValueError("only integer literals are supported")
        if len(str(abs(node.value))) > len(_PLACE_NAMES):
            raise ValueError(f"integer literals may have at most {len(_PLACE_NAMES)} digits")
        return Fraction(node.value), []

    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        operand, steps = _evaluate_arithmetic_node(node.operand)
        if isinstance(node.op, ast.UAdd):
            return operand, steps
        result = _checked_result(-operand)
        detail = (
            "0的相反数仍是0"
            if result == 0
            else f"取相反数：{_format_fraction(operand)}变为{_format_fraction(result)}"
        )
        return result, [*steps, detail]

    if isinstance(node, ast.BinOp) and isinstance(
        node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)
    ):
        left, left_steps = _evaluate_arithmetic_node(node.left)
        right, right_steps = _evaluate_arithmetic_node(node.right)
        if isinstance(node.op, ast.Add):
            result, symbol = left + right, "+"
        elif isinstance(node.op, ast.Sub):
            result, symbol = left - right, "-"
        elif isinstance(node.op, ast.Mult):
            result, symbol = left * right, "×"
        else:
            if right == 0:
                raise ArithmeticDomainError("division by zero is undefined")
            result, symbol = left / right, "÷"
        result = _checked_result(result)
        detail = (
            f"{_format_fraction(left)}{symbol}{_format_fraction(right)}="
            f"{_format_fraction(result)}"
        )
        return result, [*left_steps, *right_steps, detail]

    raise ValueError("only +, -, *, /, parentheses, and integer literals are supported")


def _normalized_arithmetic_expression(query: str) -> str:
    expression = query.translate(_SIGN_TRANSLATION).strip()
    if expression.startswith("请计算"):
        expression = expression[len("请计算") :].strip()
    expression = re.sub(
        r"\s*(?:等于多少|等于几|是多少|是几)\s*[?？。]?\s*$",
        "",
        expression,
    )
    expression = expression.rstrip("?？。").strip()
    if expression.endswith("="):
        expression = expression[:-1].strip()
    if not expression or "=" in expression:
        raise ValueError("expected one arithmetic expression")
    if len(expression) > _MAX_EXPRESSION_LENGTH:
        raise ValueError("arithmetic expression is too long")
    return expression


def solve_arithmetic_query(query: str) -> ReasoningExample:
    """Safely evaluate a bounded exact arithmetic expression without `eval`."""
    try:
        return solve_addition_query(query)
    except ValueError:
        pass

    expression = _normalized_arithmetic_expression(query)
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ValueError("invalid arithmetic expression") from exc
    if sum(1 for _ in ast.walk(tree)) > _MAX_AST_NODES:
        raise ValueError("arithmetic expression is too complex")
    result, steps = _evaluate_arithmetic_node(tree.body)
    answer = _format_fraction(result)
    completion = "；".join(steps) + f"。所以答案是{answer}。"
    prompt = f"用户：请计算{expression}。助手：推理："
    return ReasoningExample(prompt=prompt, completion=completion, answer=answer)


def extract_answer(text: str) -> str | None:
    """Extract the final integer answer from a generated reasoning trace."""
    matches = _ANSWER_PATTERN.findall(text)
    return matches[-1] if matches else None


def score_reasoning_outputs(
    expected_answers: list[str], generated_outputs: list[str]
) -> dict[str, int | float | list[str | None]]:
    """Measure exact answer accuracy; fluent-looking text earns no partial credit."""
    if len(expected_answers) != len(generated_outputs):
        raise ValueError("expected answers and generated outputs must have equal length")
    if not expected_answers:
        raise ValueError("at least one answer is required")
    predictions = [extract_answer(output) for output in generated_outputs]
    correct = sum(
        prediction == expected
        for prediction, expected in zip(predictions, expected_answers)
    )
    return {
        "correct": correct,
        "total": len(expected_answers),
        "exact_match_accuracy": correct / len(expected_answers),
        "predictions": predictions,
    }


def generate_reasoning_corpus(
    output_dir: str | Path,
    *,
    training_examples: int,
    validation_examples: int,
    max_digits: int,
    seed: int = 1337,
) -> dict[str, int | str]:
    """Write disjoint addition training data and an exact-match benchmark."""
    if training_examples <= 0 or validation_examples <= 0:
        raise ValueError("training and validation example counts must be positive")
    if not 1 <= max_digits <= len(_PLACE_NAMES):
        raise ValueError(f"max_digits must be between 1 and {len(_PLACE_NAMES)}")

    operand_count = 10**max_digits
    available_pairs = operand_count * operand_count
    total_examples = training_examples + validation_examples
    if total_examples > available_pairs:
        raise ValueError(
            f"requested {total_examples} unique addition problems, but the "
            f"{max_digits}-digit domain contains only {available_pairs}"
        )

    destination = Path(output_dir).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    pair_ids = rng.sample(range(available_pairs), total_examples)
    examples = [
        addition_example(*divmod(pair_id, operand_count)) for pair_id in pair_ids
    ]

    corpus_path = destination / "corpus.txt"
    corpus_path.write_text(
        "".join(example.text + "\n" for example in examples),
        encoding="utf-8",
    )
    benchmark_path = destination / "benchmark.jsonl"
    benchmark_path.write_text(
        "".join(
            json.dumps(
                {**asdict(example), "text": example.text},
                ensure_ascii=False,
            )
            + "\n"
            for example in examples[training_examples:]
        ),
        encoding="utf-8",
    )

    metadata: dict[str, int | str] = {
        "training_examples": training_examples,
        "validation_examples": validation_examples,
        "max_digits": max_digits,
        "seed": seed,
        "corpus": str(corpus_path),
        "benchmark": str(benchmark_path),
    }
    (destination / "metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return metadata
