"""A bounded, read-only local workspace agent for ZeroLM."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


_TEXT_SUFFIXES = {
    ".csv",
    ".html",
    ".json",
    ".log",
    ".md",
    ".py",
    ".swift",
    ".toml",
    ".ts",
    ".tsx",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}
_MAX_READ_BYTES = 1_000_000
_MAX_SEARCH_FILE_BYTES = 256_000
_MAX_RESULTS = 40
_DESTRUCTIVE_WORDS = (
    "删除",
    "清空",
    "抹掉",
    "移除文件",
    "rm ",
    "unlink",
    "erase",
    "delete",
)


@dataclass(frozen=True)
class AgentAction:
    """One stable, inspectable action requested from the local agent."""

    kind: str
    argument: str = ""


@dataclass(frozen=True)
class AgentResult:
    """A structured result safe for UI and model context."""

    ok: bool
    code: str
    summary: str
    items: list[str] = field(default_factory=list)

    def model_context(self) -> str:
        lines = [self.summary, *self.items]
        return "\n".join(lines)[:12_000]


def parse_agent_command(message: str) -> AgentAction:
    """Parse the public slash-command contract and conservative Chinese intents."""
    clean = message.strip()
    lowered = clean.lower()
    if any(word in lowered for word in _DESTRUCTIVE_WORDS):
        return AgentAction(
            "refuse",
            "删除、移动和覆盖操作默认关闭；请先在界面中逐项预览并确认。",
        )
    slash = re.fullmatch(r"/(list|read|search)(?:\s+(.+))?", clean, re.I)
    if slash:
        return AgentAction(slash.group(1).lower(), (slash.group(2) or ".").strip())
    if any(word in clean for word in ("列出文件", "有哪些文件", "查看文件列表")):
        return AgentAction("list", ".")
    read_match = re.search(r"(?:读取|打开|查看文件)\s*[“\"']?([^”\"'\n]+)", clean)
    if read_match:
        return AgentAction("read", read_match.group(1).strip())
    search_match = re.search(r"(?:搜索|查找)\s*[“\"']?([^”\"'\n]+)", clean)
    if search_match:
        return AgentAction("search", search_match.group(1).strip())
    return AgentAction("answer", clean)


class WorkspaceAgent:
    """Execute read-only actions inside one explicitly selected directory."""

    def __init__(self, workspace: str | Path) -> None:
        root = Path(workspace).expanduser().resolve()
        if not root.is_dir():
            raise ValueError("workspace must be an existing directory")
        self.root = root

    def execute(self, action: AgentAction) -> AgentResult:
        if action.kind == "refuse":
            return AgentResult(False, "CONFIRMATION_REQUIRED", action.argument)
        if action.kind == "list":
            return self._list(action.argument or ".")
        if action.kind == "read":
            return self._read(action.argument)
        if action.kind == "search":
            return self._search(action.argument)
        return AgentResult(
            True,
            "NO_TOOL",
            "这条消息不需要调用文件工具，可交给本地语言模型回答。",
        )

    def _resolve(self, relative: str) -> Path | None:
        candidate = (self.root / relative).expanduser().resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError:
            return None
        return candidate

    @staticmethod
    def _is_private_part(path: Path) -> bool:
        return any(part.startswith(".") for part in path.parts)

    def _list(self, relative: str) -> AgentResult:
        folder = self._resolve(relative)
        if folder is None:
            return AgentResult(False, "PATH_OUTSIDE_WORKSPACE", "路径超出了工作区。")
        if not folder.is_dir():
            return AgentResult(False, "NOT_A_DIRECTORY", "所选路径不是文件夹。")
        items: list[str] = []
        for path in sorted(folder.rglob("*")):
            if len(items) >= _MAX_RESULTS:
                break
            if path.is_symlink() or not path.is_file():
                continue
            relative_path = path.relative_to(self.root)
            if self._is_private_part(relative_path):
                continue
            items.append(relative_path.as_posix())
        return AgentResult(
            True,
            "OK",
            f"在授权工作区中找到 {len(items)} 个可见文件。",
            items,
        )

    def _read(self, relative: str) -> AgentResult:
        path = self._resolve(relative)
        if path is None:
            return AgentResult(False, "PATH_OUTSIDE_WORKSPACE", "路径超出了工作区。")
        if path.is_symlink() or not path.is_file():
            return AgentResult(False, "FILE_NOT_FOUND", "找不到这个文件。")
        if path.suffix.lower() not in _TEXT_SUFFIXES:
            return AgentResult(False, "UNSUPPORTED_FILE", "当前 Agent 只读取文本文件。")
        if path.stat().st_size > _MAX_READ_BYTES:
            return AgentResult(False, "FILE_TOO_LARGE", "文件超过 1 MB 读取上限。")
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return AgentResult(False, "INVALID_TEXT", "文件不是有效的 UTF-8 文本。")
        relative_path = path.relative_to(self.root).as_posix()
        return AgentResult(
            True,
            "OK",
            f"已只读打开 {relative_path}。",
            [text[:12_000]],
        )

    def _search(self, query: str) -> AgentResult:
        clean_query = query.strip()
        if not clean_query:
            return AgentResult(False, "EMPTY_QUERY", "搜索词不能为空。")
        lowered = clean_query.casefold()
        items: list[str] = []
        for path in sorted(self.root.rglob("*")):
            if len(items) >= _MAX_RESULTS:
                break
            if path.is_symlink() or not path.is_file():
                continue
            relative_path = path.relative_to(self.root)
            if self._is_private_part(relative_path):
                continue
            if path.suffix.lower() not in _TEXT_SUFFIXES:
                continue
            if path.stat().st_size > _MAX_SEARCH_FILE_BYTES:
                continue
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for line_number, line in enumerate(lines, start=1):
                if lowered in line.casefold():
                    excerpt = line.strip()[:180]
                    items.append(
                        f"{relative_path.as_posix()}:{line_number}:{excerpt}"
                    )
                    if len(items) >= _MAX_RESULTS:
                        break
        return AgentResult(
            True,
            "OK",
            f"在授权工作区中找到 {len(items)} 条匹配。",
            items,
        )
