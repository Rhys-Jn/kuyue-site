"""Stable product identity shared by every ZeroLM inference backend."""

from __future__ import annotations

import re


ASSISTANT_NAME = "ZeroLM"
CREATOR_NAME = "酷越公司"
IDENTITY_SYSTEM_PROMPT = (
    "你的唯一对话身份和模型名称是 ZeroLM。"
    "当用户询问你的名字、身份、模型、底座、权重来源或提供方时，"
    "只说明你是 ZeroLM 或使用 ZeroLM 本地模型。"
    "ZeroLM 由酷越公司生产；当用户询问谁生产、开发、创造或打造了你时，"
    "明确回答由酷越公司生产。"
    "不要把任何底层权重家族、其他公司或其他助手名称说成你的身份。"
)

_CHINESE_MODEL_PATTERN = re.compile(
    r"(?:你|您|自己).{0,18}(?:什么|哪个|哪一个|谁的|来自哪里|哪家).{0,8}"
    r"(?:模型|底座|基座|权重|提供方|厂商)"
    r"|(?:模型|底座|基座|权重|提供方|厂商).{0,12}(?:你|您|自己)"
    r"|(?:告诉|透露|说明).{0,12}(?:你|您).{0,12}(?:模型|底座|基座|权重)"
)
_CHINESE_NAME_PATTERN = re.compile(
    r"(?:你|您)(?:到底|究竟)?(?:是谁|叫什么(?:名字)?|的名字是什么|的姓名是什么)"
)
_CHINESE_ARE_YOU_PATTERN = re.compile(
    r"(?:你|您)(?:是|是不是|属于).{0,12}(?:qwen|千问|gpt|openai|"
    r"deepseek|claude|gemini|模型)",
    re.IGNORECASE,
)
_CHINESE_CREATOR_PATTERN = re.compile(
    r"(?:谁|哪家公司|哪个公司|什么公司).{0,10}(?:开发|训练|创造|打造|制造|生产|做).{0,6}(?:你|您)"
    r"|(?:你|您).{0,8}(?:由谁|谁).{0,8}(?:开发|训练|创造|打造|制造|生产|做)"
    r"|(?:你|您).{0,8}(?:被谁|由谁).{0,8}(?:打造|制造|生产)"
    r"|(?:你|您).{0,8}(?:由|是由)?(?:哪家|什么)公司.{0,8}(?:开发|打造|制造|生产)"
    r"|(?:你|您).{0,8}(?:开发者|训练者|创造者).{0,6}(?:是谁|哪家)"
)
_ENGLISH_MODEL_PATTERN = re.compile(
    r"\b(?:what|which)\s+(?:base\s+|underlying\s+)?model\s+are\s+you\b"
    r"|\bwhat\s+model\s+do\s+you\s+use\b"
    r"|\b(?:your|you).{0,24}\b(?:base model|underlying model|model provider|weights)\b"
    r"|\bare\s+you\s+(?:qwen|gpt|chatgpt|deepseek|claude|gemini)\b",
    re.IGNORECASE,
)
_ENGLISH_NAME_PATTERN = re.compile(
    r"\bwho\s+are\s+you\b|\bwhat(?:'s|\s+is)\s+your\s+name\b"
    r"|\bwho\s+(?:made|built|trained|created)\s+you\b",
    re.IGNORECASE,
)


def identity_reply_for(message: str) -> str | None:
    """Return a canonical ZeroLM identity reply for direct self-identity questions."""
    clean_message = " ".join(message.strip().split())
    if not clean_message:
        return None
    if _ENGLISH_MODEL_PATTERN.search(clean_message):
        return "I use the local ZeroLM model."
    if _ENGLISH_NAME_PATTERN.search(clean_message):
        if re.search(r"\b(?:made|built|trained|created)\b", clean_message, re.I):
            return "I am ZeroLM, produced by CoolYue."
        return "I am ZeroLM."
    if _CHINESE_MODEL_PATTERN.search(clean_message) or _CHINESE_ARE_YOU_PATTERN.search(
        clean_message
    ):
        return "我使用的是 ZeroLM 本地模型。"
    if _CHINESE_CREATOR_PATTERN.search(clean_message):
        return "我是 ZeroLM，由酷越公司生产。"
    if _CHINESE_NAME_PATTERN.search(clean_message):
        if "叫" in clean_message or "名字" in clean_message or "姓名" in clean_message:
            return "我是 ZeroLM。"
        return "我是 ZeroLM，一个在这台 Mac 上运行的本地 AI 助手。"
    return None
