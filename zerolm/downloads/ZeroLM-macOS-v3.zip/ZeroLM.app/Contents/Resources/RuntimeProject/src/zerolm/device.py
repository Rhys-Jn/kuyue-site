"""Training device selection with Apple Silicon as the primary target."""

from __future__ import annotations

import torch


def select_device(
    preferred: str = "auto",
    *,
    mps_available: bool | None = None,
    cuda_available: bool | None = None,
) -> torch.device:
    """Select MPS first, CUDA second, then CPU, or validate an override."""
    if preferred not in {"auto", "mps", "cuda", "cpu"}:
        raise ValueError("device must be one of: auto, mps, cuda, cpu")

    has_mps = torch.backends.mps.is_available() if mps_available is None else mps_available
    has_cuda = torch.cuda.is_available() if cuda_available is None else cuda_available

    if preferred == "mps":
        if not has_mps:
            raise RuntimeError("MPS was requested but is not available")
        return torch.device("mps")
    if preferred == "cuda":
        if not has_cuda:
            raise RuntimeError("CUDA was requested but is not available")
        return torch.device("cuda")
    if preferred == "cpu":
        return torch.device("cpu")
    if has_mps:
        return torch.device("mps")
    if has_cuda:
        return torch.device("cuda")
    return torch.device("cpu")
