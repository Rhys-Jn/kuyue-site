"""Local MLX inference for ZeroLM's open-weight assistant mode."""

from __future__ import annotations

import math
import os
from importlib.metadata import PackageNotFoundError, version
from importlib.util import find_spec
from pathlib import Path
from platform import machine
from typing import Callable, Iterator, Mapping, Sequence

from packaging.version import InvalidVersion, Version

from zerolm.conversation import normalize_history_messages
from zerolm.identity import IDENTITY_SYSTEM_PROMPT, identity_reply_for

DEFAULT_MODEL_ID = "Qwen/Qwen3-4B-MLX-4bit"
DEFAULT_MODEL_REVISION = "52a5ab34fa604bc8af6d3ce0cac0cab10b7eb495"
MATH_MODEL_ID = "mlx-community/DeepSeek-R1-Distill-Qwen-7B-4bit"
MATH_MODEL_REVISION = "21848dbf533d2518a1ef895104820d5ee51317ea"
MODEL_LICENSE = "Apache-2.0"
MINIMUM_MLX_LM_VERSION = "0.25.2"
SYSTEM_PROMPT = (
    IDENTITY_SYSTEM_PROMPT
    + "你是 ZeroLM 的本地日常助手。"
    "请用用户所用语言简洁、诚实地回答；不确定时明确说明。"
)
MATH_SYSTEM_PROMPT = (
    IDENTITY_SYSTEM_PROMPT
    + "你是 ZeroLM 的本地数学助手。"
    "先在内部认真推理，再给出简洁、可核对的步骤和最终答案。"
    "不确定或题目信息不足时明确说明；不要伪造精确性。"
)


class OpenModelUnavailable(RuntimeError):
    """Raised when the optional local MLX runtime cannot be used."""


def pinned_model_snapshot_path(model_id: str, revision: str) -> Path:
    """Return the exact Hugging Face cache path for one pinned model revision."""
    hf_home = Path(os.environ.get("HF_HOME", Path.home() / ".cache/huggingface"))
    hub_cache = Path(os.environ.get("HF_HUB_CACHE", hf_home / "hub"))
    cache_name = "models--" + model_id.replace("/", "--")
    return hub_cache / cache_name / "snapshots" / revision


def default_model_snapshot_path() -> Path:
    """Return the exact Hugging Face cache path for the pinned Qwen revision."""
    return pinned_model_snapshot_path(DEFAULT_MODEL_ID, DEFAULT_MODEL_REVISION)


def _runtime_diagnostics_for(
    model_id: str,
    revision: str,
    *,
    publisher: str,
    parameters: str,
    download_bytes: int,
) -> dict[str, object]:
    installed = find_spec("mlx_lm") is not None
    installed_version: str | None = None
    if installed:
        try:
            installed_version = version("mlx-lm")
        except PackageNotFoundError:
            installed = False
    try:
        version_supported = installed_version is not None and Version(
            installed_version
        ) >= Version(MINIMUM_MLX_LM_VERSION)
    except InvalidVersion:
        version_supported = False
    architecture = machine()
    snapshot = pinned_model_snapshot_path(model_id, revision)
    model_cached = snapshot.is_dir() and (snapshot / "model.safetensors").is_file()
    apple_silicon = architecture == "arm64"
    return {
        "model_id": model_id,
        "revision": revision,
        "publisher": publisher,
        "source": f"https://huggingface.co/{model_id}",
        "license": MODEL_LICENSE,
        "quantization": "4-bit",
        "parameters": parameters,
        "mlx_lm_minimum": MINIMUM_MLX_LM_VERSION,
        "mlx_lm_installed": installed,
        "mlx_lm_version": installed_version,
        "version_supported": version_supported,
        "architecture": architecture,
        "apple_silicon": apple_silicon,
        "model_cached": model_cached,
        "model_path": str(snapshot) if model_cached else None,
        "download_bytes": download_bytes,
        "ready": version_supported and apple_silicon and model_cached,
    }


def runtime_diagnostics() -> dict[str, object]:
    """Return a side-effect-free assistant readiness report."""
    return _runtime_diagnostics_for(
        DEFAULT_MODEL_ID,
        DEFAULT_MODEL_REVISION,
        publisher="Qwen",
        parameters="4B",
        download_bytes=2_200_000_000,
    )


def math_runtime_diagnostics() -> dict[str, object]:
    """Return a side-effect-free math readiness report."""
    return _runtime_diagnostics_for(
        MATH_MODEL_ID,
        MATH_MODEL_REVISION,
        publisher="DeepSeek / MLX Community conversion",
        parameters="7B",
        download_bytes=4_500_000_000,
    )


def _mlx_functions() -> tuple[
    Callable[..., object], Callable[..., str], Callable[..., object]
]:
    if find_spec("mlx_lm") is None:
        raise OpenModelUnavailable(
            "缺少本地 MLX 后端；请安装 requirements-mlx.lock（mlx-lm），无需付费 API。"
        )
    from mlx_lm import generate, load
    from mlx_lm.sample_utils import make_sampler

    return load, generate, make_sampler


def generate_reply(
    message: str,
    *,
    model_id: str = DEFAULT_MODEL_ID,
    revision: str | None = None,
    adapter_path: str | Path | None = None,
    max_tokens: int = 256,
    temperature: float = 0.2,
    thinking: bool = False,
    show_thinking: bool = False,
    system_prompt: str = SYSTEM_PROMPT,
    history: Sequence[Mapping[str, str]] | None = None,
    loader: Callable[..., object] | None = None,
    generator: Callable[..., str] | None = None,
    sampler_factory: Callable[..., object] | None = None,
) -> str:
    """Generate one chat reply with the local Qwen MLX model."""
    clean_message = message.strip()
    if not clean_message:
        raise ValueError("message must not be empty")
    if not 1 <= max_tokens <= 2048:
        raise ValueError("max_tokens must be between 1 and 2048")
    if not math.isfinite(temperature) or not 0 <= temperature <= 2:
        raise ValueError("temperature must be finite and between 0 and 2")
    history_messages = normalize_history_messages(history)
    identity_reply = identity_reply_for(clean_message)
    if identity_reply is not None:
        return identity_reply

    if loader is None or generator is None or sampler_factory is None:
        loader, generator, sampler_factory = _mlx_functions()

    selected_revision = revision
    if selected_revision is None:
        if model_id == DEFAULT_MODEL_ID:
            selected_revision = DEFAULT_MODEL_REVISION
        elif model_id == MATH_MODEL_ID:
            selected_revision = MATH_MODEL_REVISION
    model_source = model_id
    pinned_revision = (
        (model_id == DEFAULT_MODEL_ID and selected_revision == DEFAULT_MODEL_REVISION)
        or (model_id == MATH_MODEL_ID and selected_revision == MATH_MODEL_REVISION)
    )
    if pinned_revision:
        snapshot = (
            default_model_snapshot_path()
            if model_id == DEFAULT_MODEL_ID
            else pinned_model_snapshot_path(model_id, selected_revision)
        )
        if snapshot.is_dir() and (snapshot / "model.safetensors").is_file():
            model_source = str(snapshot)
            selected_revision = None
    load_options: dict[str, object] = {}
    if selected_revision is not None:
        load_options["revision"] = selected_revision
    if adapter_path is not None:
        load_options["adapter_path"] = str(adapter_path)
    model, tokenizer = loader(model_source, **load_options)
    prompt = tokenizer.apply_chat_template(
        [
            {"role": "system", "content": system_prompt},
            *history_messages,
            {"role": "user", "content": clean_message},
        ],
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=thinking,
    )
    sampler_options: dict[str, object] = {}
    if thinking:
        sampler_options = {"top_p": 0.95, "top_k": 20, "min_p": 0.0}
    reply = generator(
        model,
        tokenizer,
        prompt=prompt,
        max_tokens=max_tokens,
        sampler=sampler_factory(temperature, **sampler_options),
    )
    return format_generated_reply(
        reply,
        thinking=thinking,
        show_thinking=show_thinking,
    )


def format_generated_reply(
    reply: str,
    *,
    thinking: bool,
    show_thinking: bool,
) -> str:
    clean_reply = reply.strip()
    if thinking and "<think>" in clean_reply and "</think>" not in clean_reply:
        return "这次推理在输出上限内没有完成，请简化问题或重试。"
    if "</think>" in clean_reply:
        thinking_text, answer = clean_reply.split("</think>", 1)
        thinking_text = thinking_text.replace("<think>", "").strip()
        clean_reply = answer.strip()
        if show_thinking and thinking_text:
            bounded_thinking = thinking_text[:4_000]
            return (
                f"<zerolm-thinking>\n{bounded_thinking}\n"
                f"</zerolm-thinking>\n\n{clean_reply}"
            )
    return clean_reply.replace("<think>", "").replace("</think>", "").strip()


def stream_reply(
    message: str,
    *,
    max_tokens: int = 768,
    temperature: float = 0.6,
    history: Sequence[Mapping[str, str]] | None = None,
) -> Iterator[str]:
    """Yield genuine Qwen thinking/output token chunks as they are generated."""
    clean_message = message.strip()
    if not clean_message:
        raise ValueError("message must not be empty")
    if not 1 <= max_tokens <= 2048:
        raise ValueError("max_tokens must be between 1 and 2048")
    from mlx_lm import load, stream_generate
    from mlx_lm.sample_utils import make_sampler

    snapshot = default_model_snapshot_path()
    model_source = (
        str(snapshot)
        if snapshot.is_dir() and (snapshot / "model.safetensors").is_file()
        else DEFAULT_MODEL_ID
    )
    load_options = (
        {} if model_source != DEFAULT_MODEL_ID
        else {"revision": DEFAULT_MODEL_REVISION}
    )
    model, tokenizer = load(model_source, **load_options)
    prompt = tokenizer.apply_chat_template(
        [
            {"role": "system", "content": SYSTEM_PROMPT},
            *normalize_history_messages(history),
            {"role": "user", "content": clean_message},
        ],
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=True,
    )
    sampler = make_sampler(
        temperature,
        top_p=0.95,
        top_k=20,
        min_p=0.0,
    )
    for response in stream_generate(
        model,
        tokenizer,
        prompt,
        max_tokens=max_tokens,
        sampler=sampler,
    ):
        if response.text:
            yield response.text
