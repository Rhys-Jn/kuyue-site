"""Corpus preparation and deterministic next-token training batches."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import torch

from zerolm.tokenizer import Tokenizer, _validated_inputs


def _iter_nonempty_lines(paths: Iterable[Path]) -> Iterable[str]:
    for path in paths:
        with path.open("r", encoding="utf-8") as corpus:
            for line in corpus:
                stripped = line.strip()
                if stripped:
                    yield stripped


def _count_partition_tokens(
    paths: Iterable[Path],
    tokenizer: Tokenizer,
    *,
    split_index: int,
) -> tuple[int, int]:
    train_tokens = 0
    validation_tokens = 0
    for line_index, line in enumerate(_iter_nonempty_lines(paths)):
        token_count = len(tokenizer.encode(line, add_bos=True, add_eos=True))
        if line_index < split_index:
            train_tokens += token_count
        else:
            validation_tokens += token_count
    return train_tokens, validation_tokens


def _write_partition_arrays(
    paths: Iterable[Path],
    tokenizer: Tokenizer,
    *,
    split_index: int,
    train_path: Path,
    validation_path: Path,
    train_tokens: int,
    validation_tokens: int,
    dtype: type[np.unsignedinteger],
) -> None:
    train_array = np.lib.format.open_memmap(
        train_path,
        mode="w+",
        dtype=dtype,
        shape=(train_tokens,),
    )
    validation_array = np.lib.format.open_memmap(
        validation_path,
        mode="w+",
        dtype=dtype,
        shape=(validation_tokens,),
    )
    train_offset = 0
    validation_offset = 0
    for line_index, line in enumerate(_iter_nonempty_lines(paths)):
        token_ids = tokenizer.encode(line, add_bos=True, add_eos=True)
        if line_index < split_index:
            end = train_offset + len(token_ids)
            if end > len(train_array):
                raise RuntimeError("corpus changed while it was being prepared")
            train_array[train_offset:end] = token_ids
            train_offset = end
        else:
            end = validation_offset + len(token_ids)
            if end > len(validation_array):
                raise RuntimeError("corpus changed while it was being prepared")
            validation_array[validation_offset:end] = token_ids
            validation_offset = end
    if train_offset != train_tokens or validation_offset != validation_tokens:
        raise RuntimeError("corpus changed while it was being prepared")
    train_array.flush()
    validation_array.flush()


def prepare_dataset(
    input_paths: Iterable[str | Path],
    *,
    tokenizer_path: str | Path,
    output_dir: str | Path,
    validation_fraction: float = 0.05,
) -> dict[str, int | float | str]:
    """Encode raw lines and persist deterministic train/validation arrays."""
    if not 0.0 < validation_fraction < 0.5:
        raise ValueError("validation_fraction must be between 0 and 0.5")
    paths = _validated_inputs(input_paths)
    tokenizer = Tokenizer(tokenizer_path)
    line_count = sum(1 for _ in _iter_nonempty_lines(paths))
    if line_count < 2:
        raise ValueError("corpus must contain at least two non-empty lines")

    validation_lines = max(1, round(line_count * validation_fraction))
    split_index = line_count - validation_lines
    train_token_count, validation_token_count = _count_partition_tokens(
        paths,
        tokenizer,
        split_index=split_index,
    )
    dtype = np.uint16 if tokenizer.vocab_size <= np.iinfo(np.uint16).max else np.uint32

    destination = Path(output_dir).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)
    train_path = destination / "train.npy"
    validation_path = destination / "validation.npy"
    temporary_train_path = destination / "train.npy.tmp"
    temporary_validation_path = destination / "validation.npy.tmp"
    try:
        _write_partition_arrays(
            paths,
            tokenizer,
            split_index=split_index,
            train_path=temporary_train_path,
            validation_path=temporary_validation_path,
            train_tokens=train_token_count,
            validation_tokens=validation_token_count,
            dtype=dtype,
        )
        temporary_train_path.replace(train_path)
        temporary_validation_path.replace(validation_path)
    finally:
        temporary_train_path.unlink(missing_ok=True)
        temporary_validation_path.unlink(missing_ok=True)

    metadata: dict[str, int | float | str] = {
        "tokenizer": str(Path(tokenizer_path).expanduser().resolve()),
        "vocab_size": tokenizer.vocab_size,
        "train_tokens": train_token_count,
        "validation_tokens": validation_token_count,
        "validation_fraction": validation_fraction,
        "dtype": np.dtype(dtype).name,
    }
    metadata_path = destination / "metadata.json"
    temporary_path = destination / "metadata.json.tmp"
    temporary_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary_path.replace(metadata_path)
    return metadata


def load_tokens(path: str | Path) -> np.ndarray:
    token_path = Path(path).expanduser().resolve()
    if not token_path.is_file():
        raise FileNotFoundError(f"token array does not exist: {token_path}")
    tokens = np.load(token_path, mmap_mode="r", allow_pickle=False)
    if tokens.ndim != 1 or not np.issubdtype(tokens.dtype, np.integer):
        raise ValueError("token array must be a one-dimensional integer array")
    return tokens


def sample_batch(
    tokens: np.ndarray,
    *,
    batch_size: int,
    context_length: int,
    generator: torch.Generator,
    device: torch.device,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Sample random contiguous windows and their one-token-shifted targets."""
    if batch_size <= 0:
        raise ValueError("batch_size must be positive")
    if context_length <= 0:
        raise ValueError("context_length must be positive")
    if len(tokens) <= context_length:
        raise ValueError("token array must contain more than context_length tokens")

    starts = torch.randint(
        0,
        len(tokens) - context_length,
        (batch_size,),
        generator=generator,
    ).tolist()
    inputs = np.stack([tokens[start : start + context_length] for start in starts])
    targets = np.stack([tokens[start + 1 : start + 1 + context_length] for start in starts])
    return (
        torch.as_tensor(inputs.astype(np.int64), device=device),
        torch.as_tensor(targets.astype(np.int64), device=device),
    )
