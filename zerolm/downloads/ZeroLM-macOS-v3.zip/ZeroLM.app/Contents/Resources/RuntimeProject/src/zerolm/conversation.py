"""Validated, bounded in-session conversation history."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Mapping, Sequence


MAX_HISTORY_FILE_BYTES = 64 * 1024
MAX_HISTORY_MESSAGES = 12
MAX_HISTORY_MESSAGE_CHARACTERS = 4_000
MAX_HISTORY_TOTAL_CHARACTERS = 16_000
_ALLOWED_ROLES = {"user", "assistant"}


def normalize_history(payload: object) -> list[dict[str, str]]:
    """Validate the versioned history-file payload and return safe chat messages."""
    if not isinstance(payload, dict) or set(payload) != {"version", "messages"}:
        raise ValueError("history must contain only version and messages")
    if type(payload["version"]) is not int or payload["version"] != 1:
        raise ValueError("history version must be 1")
    messages = payload["messages"]
    if not isinstance(messages, list) or len(messages) > MAX_HISTORY_MESSAGES:
        raise ValueError(f"history may contain at most {MAX_HISTORY_MESSAGES} messages")

    normalized: list[dict[str, str]] = []
    total_characters = 0
    for message in messages:
        if not isinstance(message, dict) or set(message) != {"role", "content"}:
            raise ValueError("history messages require only role and content")
        role = message["role"]
        content = message["content"]
        if not isinstance(role, str) or role not in _ALLOWED_ROLES:
            raise ValueError("history message role must be user or assistant")
        if not isinstance(content, str):
            raise ValueError("history message content must be text")
        clean_content = content.strip()
        if not clean_content:
            raise ValueError("history message content must not be empty")
        if len(clean_content) > MAX_HISTORY_MESSAGE_CHARACTERS:
            raise ValueError(
                "history message content must not exceed "
                f"{MAX_HISTORY_MESSAGE_CHARACTERS} characters"
            )
        total_characters += len(clean_content)
        if total_characters > MAX_HISTORY_TOTAL_CHARACTERS:
            raise ValueError(
                "history content must not exceed "
                f"{MAX_HISTORY_TOTAL_CHARACTERS} characters"
            )
        normalized.append({"role": role, "content": clean_content})
    return normalized


def normalize_history_messages(
    messages: Sequence[Mapping[str, str]] | None,
) -> list[dict[str, str]]:
    """Validate an in-memory history against the same contract as the file."""
    return normalize_history(
        {
            "version": 1,
            "messages": [dict(message) for message in (messages or ())],
        }
    )


def load_history_file(path: str | Path | None) -> list[dict[str, str]]:
    """Read one bounded UTF-8 JSON history file, or return no history."""
    if path is None:
        return []
    history_path = Path(path).expanduser().resolve()
    if not history_path.is_file():
        raise FileNotFoundError(f"history file does not exist: {history_path}")
    if history_path.stat().st_size > MAX_HISTORY_FILE_BYTES:
        raise ValueError("history file must not exceed 64 KiB")
    try:
        payload = json.loads(history_path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("history file must be valid UTF-8 JSON") from exc
    return normalize_history(payload)
