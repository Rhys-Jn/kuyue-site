"""Prompt normalization for the compact English-first image model."""

from __future__ import annotations

import re


_CHINESE_REPLACEMENTS = (
    ("生成一张", ""),
    ("生成一个", ""),
    ("生成", ""),
    ("画一张", ""),
    ("画一个", ""),
    ("的图片", ""),
    ("一个人", "one adult human person"),
    ("一位人", "one adult human person"),
    ("一只小狗", "one cute puppy"),
    ("小猫咪", "cute kitten"),
    ("小猫", "cute kitten"),
    ("猫咪", "cat"),
    ("小狗", "cute puppy"),
    ("狗狗", "dog"),
    ("人物", "human person"),
    ("人类", "human person"),
    ("男人", "adult man"),
    ("女人", "adult woman"),
    ("在睡觉", "sleeping peacefully"),
    ("睡觉", "sleeping peacefully"),
    ("在奔跑", "running"),
    ("在飞翔", "flying"),
    ("在花园里", "in a garden"),
    ("在森林里", "in a forest"),
    ("在海边", "on a beach"),
    ("宇宙", "outer space"),
    ("机器人", "robot"),
    ("女孩", "girl"),
    ("男孩", "boy"),
    ("可爱", "cute"),
    ("真实", "photorealistic"),
    ("卡通", "cartoon illustration"),
    ("水彩", "watercolor painting"),
    ("油画", "oil painting"),
    ("电影感", "cinematic"),
    ("高清", "high definition"),
    ("一张", ""),
    ("一个", ""),
)

_QUALITY_SUFFIX = (
    "high quality, coherent anatomy, centered composition, "
    "soft natural light, detailed, sharp focus"
)

_MIXED_SUBJECT_SUFFIX = (
    "two distinct subjects, one human and one dog, clear separation, "
    "human face must remain human, dog anatomy must remain canine, "
    "no hybrid creature, no merged bodies"
)


def optimized_prompt(prompt: str) -> str:
    """Translate common Chinese image terms and add a quality baseline."""
    normalized = prompt.strip()
    for chinese, english in _CHINESE_REPLACEMENTS:
        normalized = normalized.replace(chinese, f" {english} ")
    normalized = re.sub(r"[\u3000，。！？、：；]+", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip(" ,")
    if not normalized:
        normalized = "beautiful illustration"
    suffixes = [_QUALITY_SUFFIX]
    lowered = normalized.lower()
    has_person = any(
        token in lowered
        for token in ("person", "human", "adult man", "adult woman", "boy", "girl")
    )
    has_dog = any(token in lowered for token in ("dog", "puppy", "canine"))
    if has_person and has_dog:
        suffixes.append(_MIXED_SUBJECT_SUFFIX)
    return f"{normalized}, {', '.join(suffixes)}"
