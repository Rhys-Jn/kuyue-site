"""Validated configuration objects and hardware-conscious model presets."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class ModelConfig:
    vocab_size: int
    context_length: int = 256
    embedding_dim: int = 384
    num_layers: int = 6
    num_heads: int = 6
    dropout: float = 0.0
    bias: bool = False

    def validate(self) -> None:
        positive = {
            "vocab_size": self.vocab_size,
            "context_length": self.context_length,
            "embedding_dim": self.embedding_dim,
            "num_layers": self.num_layers,
            "num_heads": self.num_heads,
        }
        for name, value in positive.items():
            if value <= 0:
                raise ValueError(f"{name} must be positive")
        if self.embedding_dim % self.num_heads != 0:
            raise ValueError("embedding_dim must be divisible by num_heads")
        if not 0.0 <= self.dropout < 1.0:
            raise ValueError("dropout must be in [0, 1)")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "ModelConfig":
        config = cls(**values)
        config.validate()
        return config


@dataclass(frozen=True)
class TrainConfig:
    batch_size: int = 16
    learning_rate: float = 3e-4
    weight_decay: float = 0.1
    max_steps: int = 1_000
    warmup_steps: int = 50
    gradient_accumulation_steps: int = 1
    grad_clip: float = 1.0
    eval_interval: int = 100
    eval_batches: int = 10
    checkpoint_interval: int = 500
    seed: int = 1337

    def validate(self) -> None:
        positive_ints = {
            "batch_size": self.batch_size,
            "max_steps": self.max_steps,
            "gradient_accumulation_steps": self.gradient_accumulation_steps,
            "eval_interval": self.eval_interval,
            "eval_batches": self.eval_batches,
            "checkpoint_interval": self.checkpoint_interval,
        }
        for name, value in positive_ints.items():
            if value <= 0:
                raise ValueError(f"{name} must be positive")
        if self.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if self.weight_decay < 0:
            raise ValueError("weight_decay must be non-negative")
        if self.warmup_steps < 0:
            raise ValueError("warmup_steps must be non-negative")
        if self.grad_clip <= 0:
            raise ValueError("grad_clip must be positive")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, values: dict[str, Any]) -> "TrainConfig":
        config = cls(**values)
        config.validate()
        return config


_PRESETS: dict[str, dict[str, int | float | bool]] = {
    "smoke": {
        "context_length": 64,
        "embedding_dim": 128,
        "num_layers": 2,
        "num_heads": 4,
        "dropout": 0.0,
        "bias": False,
    },
    "tiny": {
        "context_length": 256,
        "embedding_dim": 384,
        "num_layers": 6,
        "num_heads": 6,
        "dropout": 0.0,
        "bias": False,
    },
    "assistant": {
        "context_length": 128,
        "embedding_dim": 256,
        "num_layers": 6,
        "num_heads": 8,
        "dropout": 0.0,
        "bias": False,
    },
    "small": {
        "context_length": 512,
        "embedding_dim": 512,
        "num_layers": 8,
        "num_heads": 8,
        "dropout": 0.0,
        "bias": False,
    },
}


def model_preset(name: str, *, vocab_size: int) -> ModelConfig:
    try:
        values = _PRESETS[name]
    except KeyError as exc:
        choices = ", ".join(sorted(_PRESETS))
        raise ValueError(f"unknown preset {name!r}; choose one of: {choices}") from exc
    config = ModelConfig(vocab_size=vocab_size, **values)
    config.validate()
    return config


def preset_names() -> tuple[str, ...]:
    return tuple(sorted(_PRESETS))
