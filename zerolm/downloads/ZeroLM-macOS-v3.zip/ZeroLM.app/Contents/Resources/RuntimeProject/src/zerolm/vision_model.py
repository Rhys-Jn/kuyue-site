"""Pinned local image understanding with MLX-VLM on Apple Silicon."""

from __future__ import annotations

import math
import os
from contextlib import contextmanager
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from importlib.util import find_spec
from pathlib import Path
from platform import machine
from tempfile import TemporaryDirectory
from typing import Callable, Iterator, Mapping, Sequence

from packaging.version import InvalidVersion, Version

from zerolm.conversation import normalize_history_messages
from zerolm.identity import IDENTITY_SYSTEM_PROMPT, identity_reply_for

DEFAULT_VISION_MODEL_ID = "mlx-community/Qwen3-VL-4B-Instruct-4bit"
DEFAULT_VISION_MODEL_REVISION = "2fd8dacbdb8f1e54b8c005f081ec5bf79c56376b"
VISION_UPSTREAM_MODEL_ID = "Qwen/Qwen3-VL-4B-Instruct"
VISION_MODEL_LICENSE = "Apache-2.0"
MINIMUM_MLX_VLM_VERSION = "0.6.6"
_ALLOWED_IMAGE_SUFFIXES = {
    ".bmp",
    ".jpeg",
    ".jpg",
    ".png",
    ".tif",
    ".tiff",
    ".webp",
}
_MAX_IMAGE_BYTES = 30 * 1024 * 1024
_MAX_DECODED_IMAGE_PIXELS = 40_000_000
_MAX_MODEL_IMAGE_PIXELS = 1_048_576
_MAX_MODEL_IMAGE_EDGE = 4_096
_VISION_PROMPT_PREFIX = (
    IDENTITY_SYSTEM_PROMPT
    + "你是 ZeroLM 的本地图像助手。"
    "只描述图像中有证据支持的内容；看不清时明确说明。"
    "回答前先分别确认人物、动物和物体的数量与位置，再回答用户问题。"
    "除非能看到明确的犬类身体特征，否则不要把人物判断成狗；"
    "人物或动物被遮挡、模糊或形状异常时，要说明不确定，不能猜测。"
    "如果输入是电脑屏幕截图，只报告画面中确实可见的窗口、文字和控件；"
    "不能推断未显示的页面、后台状态或用户没有展示的内容。"
)


class VisionModelUnavailable(RuntimeError):
    """Raised when the optional local MLX-VLM runtime cannot be used."""


def default_vision_snapshot_path() -> Path:
    """Return the exact Hugging Face cache path for the pinned vision revision."""
    hf_home = Path(os.environ.get("HF_HOME", Path.home() / ".cache/huggingface"))
    hub_cache = Path(os.environ.get("HF_HUB_CACHE", hf_home / "hub"))
    return (
        hub_cache
        / "models--mlx-community--Qwen3-VL-4B-Instruct-4bit"
        / "snapshots"
        / DEFAULT_VISION_MODEL_REVISION
    )


def _snapshot_is_complete(snapshot: Path) -> bool:
    required = (
        "config.json",
        "model.safetensors",
        "preprocessor_config.json",
        "tokenizer.json",
    )
    return snapshot.is_dir() and all((snapshot / name).is_file() for name in required)


def runtime_diagnostics() -> dict[str, object]:
    """Return a side-effect-free readiness report; never downloads weights."""
    installed = find_spec("mlx_vlm") is not None
    installed_version: str | None = None
    runtime_importable = False
    runtime_error: str | None = None
    if installed:
        try:
            installed_version = version("mlx-vlm")
        except PackageNotFoundError:
            installed = False
        else:
            try:
                import_module("mlx_vlm")
                runtime_importable = True
            except Exception as exc:
                detail = str(exc).splitlines()[0][:200]
                runtime_error = f"{type(exc).__name__}: {detail}"
    try:
        version_supported = installed_version is not None and Version(
            installed_version
        ) >= Version(MINIMUM_MLX_VLM_VERSION)
    except InvalidVersion:
        version_supported = False
    architecture = machine()
    snapshot = default_vision_snapshot_path()
    model_cached = _snapshot_is_complete(snapshot)
    apple_silicon = architecture == "arm64"
    return {
        "model_id": DEFAULT_VISION_MODEL_ID,
        "revision": DEFAULT_VISION_MODEL_REVISION,
        "upstream_model_id": VISION_UPSTREAM_MODEL_ID,
        "publisher": "Qwen / MLX Community conversion",
        "source": f"https://huggingface.co/{DEFAULT_VISION_MODEL_ID}",
        "license": VISION_MODEL_LICENSE,
        "quantization": "4-bit",
        "parameters": "4B",
        "mlx_vlm_minimum": MINIMUM_MLX_VLM_VERSION,
        "mlx_vlm_installed": installed,
        "mlx_vlm_version": installed_version,
        "runtime_importable": runtime_importable,
        "runtime_error": runtime_error,
        "version_supported": version_supported,
        "architecture": architecture,
        "apple_silicon": apple_silicon,
        "model_cached": model_cached,
        "model_path": str(snapshot) if model_cached else None,
        "download_bytes": 3_110_000_000,
        "ready": (
            version_supported
            and runtime_importable
            and apple_silicon
            and model_cached
        ),
    }


def _vision_functions() -> tuple[
    Callable[..., object],
    Callable[..., object],
    Callable[..., str],
    Callable[..., object],
]:
    if find_spec("mlx_vlm") is None:
        raise VisionModelUnavailable(
            "缺少本地视觉后端；请安装 requirements-vision.lock（mlx-vlm），"
            "无需付费 API。"
        )
    from mlx_vlm import generate, load
    from mlx_vlm.prompt_utils import apply_chat_template
    from mlx_vlm.utils import load_config

    return load, load_config, apply_chat_template, generate


def _download_snapshot(repo_id: str, revision: str) -> str:
    from huggingface_hub import snapshot_download

    return snapshot_download(repo_id=repo_id, revision=revision)


def _validated_image_path(image: str | Path) -> Path:
    path = Path(image).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"image does not exist: {path}")
    if path.suffix.lower() not in _ALLOWED_IMAGE_SUFFIXES:
        raise ValueError("image must be JPEG, PNG, WebP, BMP, or TIFF")
    if path.stat().st_size > _MAX_IMAGE_BYTES:
        raise ValueError("image must not exceed 30 MiB")
    return path


@contextmanager
def _prepared_image_path(image: str | Path) -> Iterator[Path]:
    """Decode, orient, bound, and re-encode an untrusted image for inference."""
    path = _validated_image_path(image)
    try:
        from PIL import Image, ImageOps, UnidentifiedImageError
    except ImportError as exc:
        raise VisionModelUnavailable(
            "缺少安全图片解码组件 Pillow；请安装 requirements-vision.lock。"
        ) from exc

    try:
        with Image.open(path) as source:
            if source.format not in {"BMP", "JPEG", "PNG", "TIFF", "WEBP"}:
                raise ValueError("image content must be JPEG, PNG, WebP, BMP, or TIFF")
            decoded_pixels = source.width * source.height
            if (
                source.width < 1
                or source.height < 1
                or decoded_pixels > _MAX_DECODED_IMAGE_PIXELS
            ):
                raise ValueError("decoded image must not exceed 40 million pixels")
            source.load()
            normalized = ImageOps.exif_transpose(source).copy()
    except (Image.DecompressionBombError, UnidentifiedImageError, OSError) as exc:
        raise ValueError("image content could not be decoded safely") from exc

    scale = min(
        1.0,
        math.sqrt(_MAX_MODEL_IMAGE_PIXELS / (normalized.width * normalized.height)),
        _MAX_MODEL_IMAGE_EDGE / normalized.width,
        _MAX_MODEL_IMAGE_EDGE / normalized.height,
    )
    if scale < 1:
        target_size = (
            max(1, int(normalized.width * scale)),
            max(1, int(normalized.height * scale)),
        )
        normalized.thumbnail(target_size, Image.Resampling.LANCZOS)

    if normalized.mode in {"RGBA", "LA"} or "transparency" in normalized.info:
        rgba = normalized.convert("RGBA")
        rgb = Image.new("RGB", rgba.size, "white")
        rgb.paste(rgba, mask=rgba.getchannel("A"))
        normalized = rgb
    elif normalized.mode != "RGB":
        normalized = normalized.convert("RGB")

    with TemporaryDirectory(prefix="zerolm-vision-") as temporary_directory:
        prepared_path = Path(temporary_directory) / "image.jpg"
        normalized.save(prepared_path, format="JPEG", quality=90, optimize=True)
        yield prepared_path


def generate_vision_reply(
    message: str,
    image: str | Path,
    *,
    max_tokens: int = 256,
    temperature: float = 0.2,
    history: Sequence[Mapping[str, str]] | None = None,
    downloader: Callable[..., str] | None = None,
    loader: Callable[..., object] | None = None,
    config_loader: Callable[..., object] | None = None,
    template_applier: Callable[..., str] | None = None,
    generator: Callable[..., object] | None = None,
) -> str:
    """Generate one grounded reply for one local raster image."""
    clean_message = message.strip() or "请描述这张图片。"
    if not 1 <= max_tokens <= 1024:
        raise ValueError("max_tokens must be between 1 and 1024")
    if not math.isfinite(temperature) or not 0 <= temperature <= 2:
        raise ValueError("temperature must be finite and between 0 and 2")
    history_messages = normalize_history_messages(history)
    identity_reply = identity_reply_for(clean_message)
    if identity_reply is not None:
        with _prepared_image_path(image):
            return identity_reply

    if any(
        function is None
        for function in (loader, config_loader, template_applier, generator)
    ):
        loader, config_loader, template_applier, generator = _vision_functions()
    snapshot = default_vision_snapshot_path()
    if _snapshot_is_complete(snapshot):
        model_source = str(snapshot)
    else:
        download = downloader or _download_snapshot
        model_source = str(
            Path(
                download(
                    repo_id=DEFAULT_VISION_MODEL_ID,
                    revision=DEFAULT_VISION_MODEL_REVISION,
                )
            ).resolve()
        )

    with _prepared_image_path(image) as image_path:
        model, processor = loader(model_source)
        config = config_loader(model_source)
        history_text = "\n".join(
            (
                "用户" if item["role"] == "user" else "ZeroLM"
            )
            + "："
            + item["content"]
            for item in history_messages
        )
        contextual_prompt = _VISION_PROMPT_PREFIX
        if history_text:
            contextual_prompt += f"\n\n此前文字对话：\n{history_text}"
        formatted_prompt = template_applier(
            processor,
            config,
            f"{contextual_prompt}\n\n用户问题：{clean_message}",
            num_images=1,
        )
        result = generator(
            model,
            processor,
            formatted_prompt,
            [str(image_path)],
            verbose=False,
            max_tokens=max_tokens,
            temperature=temperature,
        )
    reply = result if isinstance(result, str) else getattr(result, "text", str(result))
    return reply.strip()
