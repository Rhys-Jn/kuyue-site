"""Deterministic pretraining, evaluation, and resumable checkpoints."""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch

from zerolm.config import TrainConfig
from zerolm.data import sample_batch
from zerolm.model import ZeroLM


CHECKPOINT_FORMAT_VERSION = 1


@dataclass(frozen=True)
class TrainResult:
    step: int
    loss: float
    validation_loss: float | None
    checkpoint_path: Path


def load_checkpoint(path: str | Path, *, device: torch.device) -> dict[str, Any]:
    checkpoint_path = Path(path).expanduser().resolve()
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"checkpoint does not exist: {checkpoint_path}")
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
    if checkpoint.get("format_version") != CHECKPOINT_FORMAT_VERSION:
        raise ValueError("unsupported checkpoint format")
    return checkpoint


def _save_checkpoint(checkpoint: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(".tmp")
    torch.save(checkpoint, temporary_path)
    temporary_path.replace(path)


def _learning_rate(step: int, config: TrainConfig) -> float:
    if config.warmup_steps and step < config.warmup_steps:
        return config.learning_rate * (step + 1) / config.warmup_steps
    decay_steps = max(1, config.max_steps - config.warmup_steps)
    progress = min(1.0, (step - config.warmup_steps) / decay_steps)
    return config.learning_rate * 0.5 * (1.0 + math.cos(math.pi * progress))


@torch.no_grad()
def _evaluate(
    model: ZeroLM,
    tokens: np.ndarray,
    *,
    config: TrainConfig,
    device: torch.device,
    generator: torch.Generator,
) -> float:
    was_training = model.training
    model.eval()
    losses: list[float] = []
    for _ in range(config.eval_batches):
        inputs, targets = sample_batch(
            tokens,
            batch_size=config.batch_size,
            context_length=model.config.context_length,
            generator=generator,
            device=device,
        )
        _, loss = model(inputs, targets)
        if loss is None:
            raise RuntimeError("model did not return evaluation loss")
        losses.append(float(loss.detach().cpu()))
    model.train(was_training)
    return sum(losses) / len(losses)


def train(
    model: ZeroLM,
    *,
    train_tokens: np.ndarray,
    validation_tokens: np.ndarray,
    config: TrainConfig,
    device: torch.device,
    output_dir: str | Path,
    tokenizer_path: str | Path | None = None,
    resume_from: str | Path | None = None,
) -> TrainResult:
    """Train until `max_steps`, saving enough state for deterministic resume."""
    config.validate()
    model.config.validate()
    destination = Path(output_dir).expanduser().resolve()
    destination.mkdir(parents=True, exist_ok=True)

    torch.manual_seed(config.seed)
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay,
        betas=(0.9, 0.95),
    )
    train_generator = torch.Generator().manual_seed(config.seed)
    eval_generator = torch.Generator().manual_seed(config.seed + 1)

    start_step = 0
    last_loss = float("nan")
    validation_loss: float | None = None
    if resume_from is not None:
        checkpoint = load_checkpoint(resume_from, device=device)
        if checkpoint["model_config"] != model.config.to_dict():
            raise ValueError("checkpoint model configuration does not match")
        model.load_state_dict(checkpoint["model_state"])
        optimizer.load_state_dict(checkpoint["optimizer_state"])
        start_step = int(checkpoint["step"])
        last_loss = float(checkpoint["loss"])
        stored_validation = checkpoint.get("validation_loss")
        validation_loss = None if stored_validation is None else float(stored_validation)
        train_generator.set_state(checkpoint["train_generator_state"].cpu())
        eval_generator.set_state(checkpoint["eval_generator_state"].cpu())

    checkpoint_path = destination / "final.pt"
    if start_step >= config.max_steps:
        return TrainResult(
            step=start_step,
            loss=last_loss,
            validation_loss=validation_loss,
            checkpoint_path=Path(resume_from).expanduser().resolve(),
        )

    model.train()
    for step_index in range(start_step, config.max_steps):
        for group in optimizer.param_groups:
            group["lr"] = _learning_rate(step_index, config)
        optimizer.zero_grad(set_to_none=True)
        accumulated_loss = 0.0

        for _ in range(config.gradient_accumulation_steps):
            inputs, targets = sample_batch(
                train_tokens,
                batch_size=config.batch_size,
                context_length=model.config.context_length,
                generator=train_generator,
                device=device,
            )
            _, loss = model(inputs, targets)
            if loss is None:
                raise RuntimeError("model did not return training loss")
            scaled_loss = loss / config.gradient_accumulation_steps
            scaled_loss.backward()
            accumulated_loss += float(loss.detach().cpu())

        torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        optimizer.step()
        completed_step = step_index + 1
        last_loss = accumulated_loss / config.gradient_accumulation_steps

        if completed_step % config.eval_interval == 0 or completed_step == config.max_steps:
            validation_loss = _evaluate(
                model,
                validation_tokens,
                config=config,
                device=device,
                generator=eval_generator,
            )

        should_save = (
            completed_step % config.checkpoint_interval == 0
            or completed_step == config.max_steps
        )
        if should_save:
            checkpoint = {
                "format_version": CHECKPOINT_FORMAT_VERSION,
                "step": completed_step,
                "loss": last_loss,
                "validation_loss": validation_loss,
                "model_config": model.config.to_dict(),
                "train_config": config.to_dict(),
                "model_state": model.state_dict(),
                "optimizer_state": optimizer.state_dict(),
                "train_generator_state": train_generator.get_state(),
                "eval_generator_state": eval_generator.get_state(),
                "tokenizer_path": (
                    None
                    if tokenizer_path is None
                    else str(Path(tokenizer_path).expanduser().resolve())
                ),
            }
            checkpoint_path = destination / (
                "final.pt"
                if completed_step == config.max_steps
                else f"step_{completed_step:08d}.pt"
            )
            _save_checkpoint(checkpoint, checkpoint_path)

    return TrainResult(
        step=config.max_steps,
        loss=last_loss,
        validation_loss=validation_loss,
        checkpoint_path=checkpoint_path,
    )
