"""Read-only inspection for user-exported WeChat conversations."""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


_ALLOWED_SUFFIXES = {".txt", ".md", ".json"}
_MAX_EXPORT_BYTES = 25 * 1024 * 1024
_LINK_ONLY = re.compile(r"^\s*https?://\S+\s*$", re.I)
_TEXT_LINE = re.compile(
    r"^(?:\[[^\]]+\]\s*)?(?P<sender>[^：:]{1,80})[：:]\s*(?P<text>.*)$"
)


@dataclass(frozen=True)
class WeChatScanReport:
    source_name: str
    message_count: int
    participant_count: int
    duplicate_count: int
    empty_count: int
    link_only_count: int
    can_delete_from_wechat: bool
    notice: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _json_messages(value: object) -> Iterable[tuple[str, str]]:
    records = value if isinstance(value, list) else []
    for record in records:
        if not isinstance(record, dict):
            continue
        sender = str(
            record.get("sender")
            or record.get("name")
            or record.get("from")
            or "未知"
        ).strip()
        text = str(
            record.get("text")
            or record.get("content")
            or record.get("message")
            or ""
        ).strip()
        yield sender[:80], text


def _text_messages(text: str) -> Iterable[tuple[str, str]]:
    for raw_line in text.splitlines():
        clean = raw_line.strip()
        if not clean:
            continue
        match = _TEXT_LINE.match(clean)
        if match:
            yield match.group("sender").strip(), match.group("text").strip()
        else:
            yield "未知", clean


def scan_wechat_export(path: str | Path) -> WeChatScanReport:
    """Inspect an explicit export without touching WeChat or modifying the file."""
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError("微信导出文件不存在")
    if source.suffix.lower() not in _ALLOWED_SUFFIXES:
        raise ValueError("只支持用户主动导出的 txt、md 或 json 文件")
    if source.stat().st_size > _MAX_EXPORT_BYTES:
        raise ValueError("微信导出文件不能超过 25 MB")
    text = source.read_text(encoding="utf-8")
    if source.suffix.lower() == ".json":
        try:
            messages = list(_json_messages(json.loads(text)))
        except json.JSONDecodeError as exc:
            raise ValueError("微信 JSON 导出格式无效") from exc
    else:
        messages = list(_text_messages(text))

    participants = {sender for sender, _ in messages if sender and sender != "未知"}
    seen: set[str] = set()
    duplicates = 0
    empty = 0
    link_only = 0
    for sender, message in messages:
        normalized = " ".join(message.casefold().split())
        if not normalized:
            empty += 1
        key = f"{sender.casefold()}\0{normalized}"
        if key in seen:
            duplicates += 1
        else:
            seen.add(key)
        if _LINK_ONLY.fullmatch(message):
            link_only += 1

    return WeChatScanReport(
        source_name=source.name,
        message_count=len(messages),
        participant_count=len(participants),
        duplicate_count=duplicates,
        empty_count=empty,
        link_only_count=link_only,
        can_delete_from_wechat=False,
        notice=(
            "ZeroLM 只检查你主动导出的副本，不会修改微信数据库。"
            "需要回到微信确认删除真实对话。"
        ),
    )
