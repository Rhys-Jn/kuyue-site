"""Checkpoint restoration and autoregressive token generation."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

import torch

from zerolm.config import ModelConfig
from zerolm.model import ZeroLM
from zerolm.training import load_checkpoint


def load_model_from_checkpoint(
    path: str | Path,
    *,
    device: torch.device,
) -> tuple[ZeroLM, dict[str, Any]]:
    checkpoint = load_checkpoint(path, device=device)
    config = ModelConfig.from_dict(checkpoint["model_config"])
    model = ZeroLM(config)
    model.load_state_dict(checkpoint["model_state"])
    model.to(device)
    model.eval()
    return model, checkpoint


@torch.no_grad()
def generate_token_ids(
    model: ZeroLM,
    prompt_ids: Iterable[int],
    *,
    max_new_tokens: int = 100,
    temperature: float = 0.8,
    top_k: int | None = 50,
    eos_id: int | None = None,
    generator: torch.Generator | None = None,
) -> list[int]:
    """Append sampled tokens, cropping only the model's visible context."""
    generated = [int(token_id) for token_id in prompt_ids]
    if not generated:
        raise ValueError("prompt must contain at least one token")
    if any(token_id < 0 or token_id >= model.config.vocab_size for token_id in generated):
        raise ValueError("prompt contains a token outside the model vocabulary")
    if max_new_tokens < 0:
        raise ValueError("max_new_tokens must be non-negative")
    if temperature < 0.0:
        raise ValueError("temperature must be non-negative")
    if top_k is not None and top_k <= 0:
        raise ValueError("top_k must be positive or None")

    device = next(model.parameters()).device
    was_training = model.training
    model.eval()
    for _ in range(max_new_tokens):
        visible = generated[-model.config.context_length :]
        inputs = torch.tensor([visible], dtype=torch.long, device=device)
        logits, _ = model(inputs)
        next_logits = logits[0, -1].float().cpu()

        if temperature == 0.0:
            next_id = int(torch.argmax(next_logits))
        else:
            next_logits = next_logits / temperature
            if top_k is not None:
                k = min(top_k, next_logits.numel())
                threshold = torch.topk(next_logits, k).values[-1]
                next_logits = next_logits.masked_fill(next_logits < threshold, -torch.inf)
            probabilities = torch.softmax(next_logits, dim=-1)
            next_id = int(torch.multinomial(probabilities, 1, generator=generator))

        generated.append(next_id)
        if eos_id is not None and next_id == eos_id:
            break

    model.train(was_training)
    return generated
