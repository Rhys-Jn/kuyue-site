"""SentencePiece tokenizer training and inference helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

import sentencepiece as spm


def _validated_inputs(input_paths: Iterable[str | Path]) -> list[Path]:
    paths = [Path(path).expanduser().resolve() for path in input_paths]
    if not paths:
        raise ValueError("at least one input corpus is required")
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(f"corpus does not exist: {path}")
        if path.stat().st_size == 0:
            raise ValueError(f"corpus is empty: {path}")
    return paths


def train_tokenizer(
    input_paths: Iterable[str | Path],
    output_prefix: str | Path,
    *,
    vocab_size: int = 4_096,
    model_type: str = "bpe",
    byte_fallback: bool = False,
) -> Path:
    """Train a brand-new tokenizer and return its `.model` path."""
    paths = _validated_inputs(input_paths)
    if vocab_size < 64:
        raise ValueError("vocab_size must be at least 64")
    if model_type not in {"bpe", "unigram", "char"}:
        raise ValueError("model_type must be one of: bpe, unigram, char")

    prefix = Path(output_prefix).expanduser().resolve()
    if prefix.suffix == ".model":
        prefix = prefix.with_suffix("")
    prefix.parent.mkdir(parents=True, exist_ok=True)

    spm.SentencePieceTrainer.train(
        input=[str(path) for path in paths],
        model_prefix=str(prefix),
        vocab_size=vocab_size,
        model_type=model_type,
        character_coverage=0.9995,
        normalization_rule_name="nmt_nfkc",
        unk_id=0,
        bos_id=1,
        eos_id=2,
        pad_id=3,
        hard_vocab_limit=False,
        byte_fallback=byte_fallback,
        shuffle_input_sentence=True,
        input_sentence_size=1_000_000,
        minloglevel=2,
    )
    return prefix.with_suffix(".model")


class Tokenizer:
    """Small validated wrapper around a trained SentencePiece model."""

    def __init__(self, model_path: str | Path) -> None:
        self.model_path = Path(model_path).expanduser().resolve()
        if not self.model_path.is_file():
            raise FileNotFoundError(f"tokenizer does not exist: {self.model_path}")
        self._processor = spm.SentencePieceProcessor(model_file=str(self.model_path))

    @property
    def vocab_size(self) -> int:
        return self._processor.vocab_size()

    @property
    def bos_id(self) -> int:
        return self._processor.bos_id()

    @property
    def unk_id(self) -> int:
        return self._processor.unk_id()

    @property
    def eos_id(self) -> int:
        return self._processor.eos_id()

    @property
    def pad_id(self) -> int:
        return self._processor.pad_id()

    def encode(
        self,
        text: str,
        *,
        add_bos: bool = False,
        add_eos: bool = False,
    ) -> list[int]:
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        return list(
            self._processor.encode(
                text,
                out_type=int,
                add_bos=add_bos,
                add_eos=add_eos,
            )
        )

    def decode(self, token_ids: Iterable[int]) -> str:
        return self._processor.decode([int(token_id) for token_id in token_ids])
