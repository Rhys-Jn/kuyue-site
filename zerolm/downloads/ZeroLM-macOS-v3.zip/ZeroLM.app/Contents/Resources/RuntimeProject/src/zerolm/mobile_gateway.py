"""Authenticated local HTTP gateway for the ZeroLM iPhone companion."""

from __future__ import annotations

import base64
import binascii
import hmac
import json
import os
import secrets
import subprocess
import sys
import tempfile
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Mapping, Protocol


MAXIMUM_REQUEST_BYTES = 12 * 1024 * 1024
MAXIMUM_MESSAGE_CHARACTERS = 4_000
MAXIMUM_HISTORY_MESSAGES = 12
MAXIMUM_IMAGE_BYTES = 8 * 1024 * 1024
ALLOWED_FIELDS = {"mode", "message", "history", "memory", "imageBase64"}
ALLOWED_MODES = {"assistant", "reasoning", "native"}
MINIMUM_TOKEN_CHARACTERS = 16


class MobileGatewayError(RuntimeError):
    pass


class ReplyRunner(Protocol):
    def generate(self, payload: dict[str, object]) -> str: ...


class LocalZeroLMRunner:
    """Run the same pinned CLI routes used by the macOS app."""

    def __init__(self, project_root: Path) -> None:
        self.project_root = project_root.resolve()
        self._lock = threading.Lock()

    def generate(self, payload: dict[str, object]) -> str:
        with self._lock, tempfile.TemporaryDirectory(prefix="zerolm-mobile-") as raw:
            temporary = Path(raw)
            os.chmod(temporary, 0o700)
            history_path = self._write_history(payload, temporary)
            command = self._command(payload, temporary)
            if history_path is not None:
                command.extend(["--history-file", str(history_path)])
            result = subprocess.run(
                command,
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=180,
                check=False,
            )
            if result.returncode != 0:
                raise MobileGatewayError("本地模型暂时无法完成请求。")
            try:
                response = json.loads(result.stdout)
                reply = response.get("reply")
            except (json.JSONDecodeError, AttributeError):
                reply = None
            if not isinstance(reply, str) or not reply.strip():
                raise MobileGatewayError("本地模型没有生成可显示的回答。")
            return reply.strip()

    def _command(
        self,
        payload: Mapping[str, object],
        temporary: Path,
    ) -> list[str]:
        prefix = [sys.executable, "-m", "zerolm.cli"]
        mode = str(payload["mode"])
        message = str(payload["message"])
        encoded_image = payload.get("imageBase64")
        if encoded_image is not None:
            if mode != "assistant" or not isinstance(encoded_image, str):
                raise MobileGatewayError("照片只能用于正常回答模式。")
            try:
                image = base64.b64decode(encoded_image, validate=True)
            except (binascii.Error, ValueError) as error:
                raise MobileGatewayError("照片数据无效。") from error
            if not image or len(image) > MAXIMUM_IMAGE_BYTES:
                raise MobileGatewayError("照片过大或为空。")
            image_path = temporary / "image"
            image_path.write_bytes(image)
            os.chmod(image_path, 0o600)
            return prefix + [
                "vision-generate",
                "--image",
                str(image_path),
                f"--message={message}",
            ]
        if mode == "reasoning":
            return prefix + [
                "math-generate",
                f"--message={message}",
                "--max-tokens",
                "512",
                "--temperature",
                "0.6",
            ]
        if mode == "native":
            return prefix + [
                "chat",
                "--device",
                "mps",
                "--checkpoint",
                "artifacts/demo/checkpoints/final.pt",
                "--tokenizer",
                "artifacts/demo/tokenizer.model",
                f"--message={message}",
                "--max-new-tokens",
                "80",
                "--temperature",
                "0.2",
                "--top-k",
                "20",
            ]
        return prefix + [
            "open-generate",
            f"--message={message}",
            "--max-tokens",
            "256",
            "--temperature",
            "0.2",
        ]

    def _write_history(
        self,
        payload: Mapping[str, object],
        temporary: Path,
    ) -> Path | None:
        raw_history = payload.get("history")
        history = list(raw_history) if isinstance(raw_history, list) else []
        normalized: list[dict[str, str]] = []
        for item in history[-MAXIMUM_HISTORY_MESSAGES:]:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            text = item.get("text")
            if role in {"user", "assistant"} and isinstance(text, str):
                normalized.append(
                    {
                        "role": role,
                        "content": text[:MAXIMUM_MESSAGE_CHARACTERS],
                    }
                )
        memory = payload.get("memory")
        if isinstance(memory, str) and memory.strip():
            normalized.extend(
                [
                    {
                        "role": "user",
                        "content": (
                            "请参考记忆篮子里的信息："
                            + memory[:MAXIMUM_MESSAGE_CHARACTERS]
                        ),
                    },
                    {"role": "assistant", "content": "我会参考这些信息。"},
                ]
            )
        if not normalized:
            return None
        path = temporary / "history.json"
        path.write_text(
            json.dumps({"version": 1, "messages": normalized}, ensure_ascii=False),
            encoding="utf-8",
        )
        os.chmod(path, 0o600)
        return path


class MobileGatewayServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        token: str,
        runner: ReplyRunner,
    ) -> None:
        self.gateway_token = token
        self.reply_runner = runner
        super().__init__(address, MobileGatewayHandler)


class MobileGatewayHandler(BaseHTTPRequestHandler):
    server: MobileGatewayServer

    def do_GET(self) -> None:
        if self.path != "/v1/health":
            self._json_error(HTTPStatus.NOT_FOUND, "未找到。")
            return
        if not self._authorized():
            self._json_error(HTTPStatus.UNAUTHORIZED, "未授权。")
            return
        self._json(HTTPStatus.OK, {"ready": True, "name": "ZeroLM"})

    def do_POST(self) -> None:
        if self.path != "/v1/chat":
            self._json_error(HTTPStatus.NOT_FOUND, "未找到。")
            return
        if not self._authorized():
            self._json_error(HTTPStatus.UNAUTHORIZED, "未授权。")
            return
        try:
            payload = self._read_payload()
            reply = self.server.reply_runner.generate(payload)
            self._json(HTTPStatus.OK, {"reply": reply})
        except (MobileGatewayError, ValueError, json.JSONDecodeError) as error:
            self._json_error(HTTPStatus.BAD_REQUEST, str(error) or "请求无效。")
        except subprocess.TimeoutExpired:
            self._json_error(HTTPStatus.GATEWAY_TIMEOUT, "本地模型响应超时。")
        except Exception:
            self._json_error(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                "ZeroLM 暂时无法处理请求。",
            )

    def log_message(self, format: str, *args: object) -> None:
        return

    def _authorized(self) -> bool:
        expected = f"Bearer {self.server.gateway_token}"
        provided = self.headers.get("Authorization", "")
        return bool(self.server.gateway_token) and hmac.compare_digest(
            provided,
            expected,
        )

    def _read_payload(self) -> dict[str, object]:
        raw_length = self.headers.get("Content-Length")
        if raw_length is None:
            raise ValueError("缺少请求长度。")
        length = int(raw_length)
        if length <= 0 or length > MAXIMUM_REQUEST_BYTES:
            raise ValueError("请求过大或为空。")
        payload = json.loads(self.rfile.read(length))
        if not isinstance(payload, dict) or set(payload) - ALLOWED_FIELDS:
            raise ValueError("请求字段无效。")
        mode = payload.get("mode")
        message = payload.get("message")
        if mode not in ALLOWED_MODES:
            raise ValueError("回答模式无效。")
        if not isinstance(message, str) or not message.strip():
            raise ValueError("消息不能为空。")
        if len(message) > MAXIMUM_MESSAGE_CHARACTERS:
            raise ValueError("消息过长。")
        history = payload.get("history", [])
        if not isinstance(history, list) or len(history) > MAXIMUM_HISTORY_MESSAGES:
            raise ValueError("历史消息无效。")
        memory = payload.get("memory")
        if memory is not None and (
            not isinstance(memory, str)
            or len(memory) > MAXIMUM_MESSAGE_CHARACTERS
        ):
            raise ValueError("记忆篮子内容无效。")
        return payload

    def _json_error(self, status: HTTPStatus, message: str) -> None:
        self._json(status, {"error": message})

    def _json(self, status: HTTPStatus, payload: Mapping[str, object]) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)


def create_server(
    host: str,
    port: int,
    *,
    token: str,
    runner: ReplyRunner | None = None,
    project_root: Path | None = None,
) -> MobileGatewayServer:
    if len(token) < MINIMUM_TOKEN_CHARACTERS:
        raise ValueError("配对密钥至少需要 16 个字符。")
    selected_runner = runner or LocalZeroLMRunner(project_root or Path.cwd())
    return MobileGatewayServer((host, port), token, selected_runner)


def serve_mobile(
    host: str,
    port: int,
    token: str | None,
    project_root: Path | None = None,
) -> None:
    pairing_token = token or secrets.token_urlsafe(24)
    server = create_server(
        host,
        port,
        token=pairing_token,
        project_root=project_root,
    )
    print(f"ZeroLM 手机网关：http://{host}:{server.server_port}")
    print(f"配对密钥：{pairing_token}")
    print("仅在可信的私人局域网中使用。按 Control-C 停止。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
