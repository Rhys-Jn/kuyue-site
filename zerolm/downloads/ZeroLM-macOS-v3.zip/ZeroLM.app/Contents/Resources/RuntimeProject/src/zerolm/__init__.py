"""ZeroLM: a zero-cost local MLX assistant and model experiment stack."""

__version__ = "2.0.0"
