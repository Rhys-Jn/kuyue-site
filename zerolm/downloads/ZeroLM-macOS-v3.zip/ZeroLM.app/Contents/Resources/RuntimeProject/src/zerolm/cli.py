"""Command-line interface for the complete ZeroLM local workflow."""

from __future__ import annotations

import argparse
import json
import subprocess
from importlib.resources import files
from pathlib import Path
from typing import Sequence

import torch

from zerolm.config import TrainConfig, model_preset, preset_names
from zerolm.conversation import load_history_file, normalize_history_messages
from zerolm.data import load_tokens, prepare_dataset
from zerolm.device import select_device
from zerolm.generation import generate_token_ids, load_model_from_checkpoint
from zerolm.identity import identity_reply_for
from zerolm.local_agent import WorkspaceAgent, parse_agent_command
from zerolm.model import ZeroLM
from zerolm.open_lora import build_training_command as build_open_lora_command
from zerolm.open_lora import prepare_chat_dataset as prepare_open_lora_dataset
from zerolm.open_model import (
    DEFAULT_MODEL_ID,
    MATH_MODEL_ID,
    MATH_MODEL_REVISION,
    MATH_SYSTEM_PROMPT,
    format_generated_reply,
    generate_reply as generate_open_reply,
    stream_reply as stream_open_reply,
)
from zerolm.open_model import runtime_diagnostics as open_runtime_diagnostics
from zerolm.open_model import math_runtime_diagnostics
from zerolm.reasoning import (
    ArithmeticDomainError,
    generate_reasoning_corpus,
    score_reasoning_outputs,
    solve_arithmetic_query,
)
from zerolm.tokenizer import Tokenizer, train_tokenizer
from zerolm.training import train
from zerolm.vision_model import (
    DEFAULT_VISION_MODEL_ID,
    generate_vision_reply,
    runtime_diagnostics as vision_runtime_diagnostics,
)
from zerolm.wechat_bridge import scan_wechat_export


def _print_json(values: dict[str, object]) -> None:
    print(json.dumps(values, ensure_ascii=False, indent=2))


def _doctor(args: argparse.Namespace) -> int:
    device = select_device(args.device)
    _print_json(
        {
            "torch_version": torch.__version__,
            "mps_built": torch.backends.mps.is_built(),
            "mps_available": torch.backends.mps.is_available(),
            "cuda_available": torch.cuda.is_available(),
            "selected_device": device.type,
        }
    )
    return 0


def _tokenizer(args: argparse.Namespace) -> int:
    model_path = train_tokenizer(
        args.input,
        args.output,
        vocab_size=args.vocab_size,
        model_type=args.model_type,
        byte_fallback=args.byte_fallback,
    )
    tokenizer = Tokenizer(model_path)
    _print_json({"tokenizer": str(model_path), "vocab_size": tokenizer.vocab_size})
    return 0


def _prepare(args: argparse.Namespace) -> int:
    metadata = prepare_dataset(
        args.input,
        tokenizer_path=args.tokenizer,
        output_dir=args.output_dir,
        validation_fraction=args.validation_fraction,
    )
    _print_json(metadata)
    return 0


def _reasoning_data(args: argparse.Namespace) -> int:
    metadata = generate_reasoning_corpus(
        args.output_dir,
        training_examples=args.training_examples,
        validation_examples=args.validation_examples,
        max_digits=args.max_digits,
        seed=args.seed,
    )
    _print_json(metadata)
    return 0


def _reasoning_eval(args: argparse.Namespace) -> int:
    benchmark_path = Path(args.benchmark).expanduser().resolve()
    if not benchmark_path.is_file():
        raise FileNotFoundError(f"benchmark does not exist: {benchmark_path}")
    records = [
        json.loads(line)
        for line in benchmark_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if args.limit is not None:
        records = records[: args.limit]
    if not records:
        raise ValueError("benchmark must contain at least one example")

    device = select_device(args.device)
    model, checkpoint = load_model_from_checkpoint(args.checkpoint, device=device)
    tokenizer_path = args.tokenizer or checkpoint.get("tokenizer_path")
    if not tokenizer_path:
        raise ValueError("tokenizer path is required and is absent from the checkpoint")
    tokenizer = Tokenizer(tokenizer_path)
    generated_outputs: list[str] = []
    for record in records:
        prompt_ids = tokenizer.encode(str(record["prompt"]), add_bos=True)
        generated = generate_token_ids(
            model,
            prompt_ids,
            max_new_tokens=args.max_new_tokens,
            temperature=0.0,
            top_k=None,
            eos_id=tokenizer.eos_id,
        )
        generated_outputs.append(tokenizer.decode(generated[len(prompt_ids) :]))

    expected_answers = [str(record["answer"]) for record in records]
    score = score_reasoning_outputs(expected_answers, generated_outputs)
    predictions = score.pop("predictions")
    score.update(
        {
            "device": device.type,
            "checkpoint_step": int(checkpoint["step"]),
            "samples": [
                {
                    "prompt": record["prompt"],
                    "expected": expected,
                    "predicted": predicted,
                    "generated": generated,
                }
                for record, expected, predicted, generated in zip(
                    records[:10],
                    expected_answers[:10],
                    predictions[:10],
                    generated_outputs[:10],
                )
            ],
        }
    )
    _print_json(score)
    return 0


def _solve(args: argparse.Namespace) -> int:
    try:
        example = solve_arithmetic_query(args.expression)
    except ArithmeticDomainError:
        _print_json(
            {
                "expression": args.expression,
                "answer": None,
                "reply": "除数不能为零；这个表达式没有定义。",
                "defined": False,
                "verified": True,
            }
        )
        return 0
    except ValueError:
        _print_json(
            {
                "expression": args.expression,
                "answer": None,
                "reply": "算术推理模式支持六位整数、加减乘除与括号，例如(-3+8)×2。",
                "verified": False,
            }
        )
        return 0
    _print_json(
        {
            "expression": args.expression,
            "answer": example.answer,
            "reply": example.completion,
            "verified": True,
        }
    )
    return 0


def _open_doctor(args: argparse.Namespace) -> int:
    _print_json(open_runtime_diagnostics())
    return 0


def _math_doctor(args: argparse.Namespace) -> int:
    _print_json(math_runtime_diagnostics())
    return 0


def _open_generate(args: argparse.Namespace) -> int:
    if args.stream:
        raw_reply = ""
        for delta in stream_open_reply(
            args.message,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            history=load_history_file(args.history_file),
        ):
            raw_reply += delta
            print(
                json.dumps(
                    {"event": "delta", "text": delta},
                    ensure_ascii=False,
                ),
                flush=True,
            )
        reply = format_generated_reply(
            raw_reply,
            thinking=True,
            show_thinking=True,
        )
        print(
            json.dumps(
                {
                    "event": "complete",
                    "message": args.message,
                    "reply": reply,
                    "model_id": args.model,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0
    reply = generate_open_reply(
        args.message,
        model_id=args.model,
        adapter_path=args.adapter,
        max_tokens=args.max_tokens,
        temperature=args.temperature,
        thinking=args.thinking,
        show_thinking=args.thinking,
        history=load_history_file(args.history_file),
    )
    _print_json({"message": args.message, "reply": reply, "model_id": args.model})
    return 0


def _vision_doctor(args: argparse.Namespace) -> int:
    _print_json(vision_runtime_diagnostics())
    return 0


def _mobile_serve(args: argparse.Namespace) -> int:
    from zerolm.mobile_gateway import serve_mobile

    serve_mobile(args.host, args.port, args.token, Path.cwd())
    return 0


def _vision_generate(args: argparse.Namespace) -> int:
    image_path = Path(args.image).expanduser().resolve()
    reply = generate_vision_reply(
        args.message,
        image_path,
        max_tokens=args.max_tokens,
        temperature=args.temperature,
        history=load_history_file(args.history_file),
    )
    _print_json(
        {
            "message": args.message,
            "image": str(image_path),
            "reply": reply,
            "model_id": DEFAULT_VISION_MODEL_ID,
        }
    )
    return 0


def _agent_run(args: argparse.Namespace) -> int:
    action = parse_agent_command(args.message)
    result = WorkspaceAgent(args.workspace).execute(action)
    reply = result.model_context()
    if args.answer and result.ok:
        tool_context = (
            "你是 ZeroLM 的只读本地 Agent。你只能根据下面经过边界检查的"
            "工具结果回答，不能声称修改、删除或运行了文件。\n\n"
            f"用户请求：{args.message}\n\n工具结果：\n{result.model_context()}"
        )
        reply = generate_open_reply(
            tool_context,
            max_tokens=args.max_tokens,
            temperature=0.2,
        )
    _print_json(
        {
            "workspace": str(Path(args.workspace).expanduser().resolve()),
            "action": {
                "kind": action.kind,
                "argument": action.argument,
            },
            "result": {
                "ok": result.ok,
                "code": result.code,
                "summary": result.summary,
                "items": result.items,
            },
            "reply": reply,
        }
    )
    return 0


def _wechat_scan(args: argparse.Namespace) -> int:
    _print_json(scan_wechat_export(args.input).to_dict())
    return 0


def _math_generate(args: argparse.Namespace) -> int:
    history = load_history_file(args.history_file)
    identity_reply = identity_reply_for(args.message)
    if identity_reply is not None:
        _print_json(
            {
                "message": args.message,
                "answer": None,
                "reply": identity_reply,
                "defined": None,
                "verified": True,
                "engine": "zerolm-identity",
                "model_id": DEFAULT_MODEL_ID,
            }
        )
        return 0
    try:
        example = solve_arithmetic_query(args.message)
    except ArithmeticDomainError:
        _print_json(
            {
                "message": args.message,
                "answer": None,
                "reply": "除数不能为零；这个表达式没有定义。",
                "defined": False,
                "verified": True,
                "engine": "exact-arithmetic",
                "model_id": None,
            }
        )
        return 0
    except ValueError:
        reply = generate_open_reply(
            args.message,
            model_id=MATH_MODEL_ID,
            revision=MATH_MODEL_REVISION,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            thinking=True,
            system_prompt=MATH_SYSTEM_PROMPT,
            history=history,
        )
        _print_json(
            {
                "message": args.message,
                "answer": None,
                "reply": reply,
                "defined": None,
                "verified": False,
                "engine": "zerolm-thinking",
                "model_id": MATH_MODEL_ID,
            }
        )
        return 0
    _print_json(
        {
            "message": args.message,
            "answer": example.answer,
            "reply": example.completion,
            "defined": True,
            "verified": True,
            "engine": "exact-arithmetic",
            "model_id": None,
        }
    )
    return 0


def _open_lora_prepare(args: argparse.Namespace) -> int:
    _print_json(
        prepare_open_lora_dataset(
            args.input,
            args.output_dir,
            validation_count=args.validation_count,
            seed=args.seed,
            data_license=args.data_license,
        )
    )
    return 0


def _open_lora_train(args: argparse.Namespace) -> int:
    command = build_open_lora_command(
        args.data_dir,
        args.adapter_path,
        model_id=args.model,
        iterations=args.iterations,
        learning_rate=args.learning_rate,
        batch_size=args.batch_size,
        num_layers=args.num_layers,
    )
    if args.dry_run:
        _print_json({"started": False, "command": command})
        return 0
    subprocess.run(command, check=True)
    return 0


def _training_config(args: argparse.Namespace) -> TrainConfig:
    default_interval = max(1, min(100, args.max_steps))
    return TrainConfig(
        batch_size=args.batch_size,
        learning_rate=args.learning_rate,
        max_steps=args.max_steps,
        warmup_steps=min(args.warmup_steps, max(0, args.max_steps - 1)),
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        eval_interval=args.eval_interval or default_interval,
        eval_batches=args.eval_batches,
        checkpoint_interval=args.checkpoint_interval or default_interval,
        seed=args.seed,
    )


def _train(args: argparse.Namespace) -> int:
    tokenizer = Tokenizer(args.tokenizer)
    model_config = model_preset(args.preset, vocab_size=tokenizer.vocab_size)
    model = ZeroLM(model_config)
    device = select_device(args.device)
    result = train(
        model,
        train_tokens=load_tokens(Path(args.data_dir) / "train.npy"),
        validation_tokens=load_tokens(Path(args.data_dir) / "validation.npy"),
        config=_training_config(args),
        device=device,
        output_dir=args.output_dir,
        tokenizer_path=args.tokenizer,
        resume_from=args.resume,
    )
    _print_json(
        {
            "device": device.type,
            "parameter_count": model.num_parameters(),
            "step": result.step,
            "loss": result.loss,
            "validation_loss": result.validation_loss,
            "checkpoint": str(result.checkpoint_path),
        }
    )
    return 0


def _generate(args: argparse.Namespace) -> int:
    device = select_device(args.device)
    model, checkpoint = load_model_from_checkpoint(args.checkpoint, device=device)
    tokenizer_path = args.tokenizer or checkpoint.get("tokenizer_path")
    if not tokenizer_path:
        raise ValueError("tokenizer path is required and is absent from the checkpoint")
    tokenizer = Tokenizer(tokenizer_path)
    prompt_ids = tokenizer.encode(args.prompt, add_bos=True)
    generator = torch.Generator().manual_seed(args.seed)
    generated = generate_token_ids(
        model,
        prompt_ids,
        max_new_tokens=args.max_new_tokens,
        temperature=args.temperature,
        top_k=args.top_k,
        eos_id=tokenizer.eos_id,
        generator=generator,
    )
    _print_json(
        {
            "device": device.type,
            "step": int(checkpoint["step"]),
            "generated_text": tokenizer.decode(generated),
        }
    )
    return 0


def _chat_reply(
    model: ZeroLM,
    tokenizer: Tokenizer,
    message: str,
    *,
    max_new_tokens: int,
    temperature: float,
    top_k: int,
    generator: torch.Generator,
    history: list[dict[str, str]] | None = None,
) -> str:
    history_messages = normalize_history_messages(history)
    identity_reply = identity_reply_for(message)
    if identity_reply is not None:
        return identity_reply
    transcript = "".join(
        ("用户：" if item["role"] == "user" else "助手：") + item["content"]
        for item in history_messages
    )
    prompt = f"{transcript}用户：{message.rstrip('。！？.!?')}助手："
    prompt_ids = tokenizer.encode(prompt, add_bos=True)
    generated = generate_token_ids(
        model,
        prompt_ids,
        max_new_tokens=max_new_tokens,
        temperature=temperature,
        top_k=top_k,
        eos_id=tokenizer.eos_id,
        generator=generator,
    )
    reply = tokenizer.decode(generated[len(prompt_ids) :]).strip()
    for marker in ("助手:", "助手：", "Assistant:"):
        if marker in reply:
            reply = reply.split(marker, 1)[-1].strip()
    return reply.split("用户：", 1)[0].strip()


def _chat(args: argparse.Namespace) -> int:
    history = load_history_file(args.history_file)
    device = select_device(args.device)
    model, checkpoint = load_model_from_checkpoint(args.checkpoint, device=device)
    tokenizer_path = args.tokenizer or checkpoint.get("tokenizer_path")
    if not tokenizer_path:
        raise ValueError("tokenizer path is required and is absent from the checkpoint")
    tokenizer = Tokenizer(tokenizer_path)
    generator = torch.Generator().manual_seed(args.seed)

    if args.message is not None:
        reply = _chat_reply(
            model,
            tokenizer,
            args.message,
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            generator=generator,
            history=history,
        )
        _print_json({"message": args.message, "reply": reply})
        return 0

    print("已进入 ZeroLM 对话。输入 /quit 退出。")
    while True:
        try:
            message = input("你：").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if message.lower() in {"/quit", "/exit", "quit", "exit"}:
            return 0
        if not message:
            continue
        reply = _chat_reply(
            model,
            tokenizer,
            message,
            max_new_tokens=args.max_new_tokens,
            temperature=args.temperature,
            top_k=args.top_k,
            generator=generator,
            history=history,
        )
        print(f"ZeroLM：{reply or '[没有生成内容]'}")


def _demo(args: argparse.Namespace) -> int:
    work_dir = Path(args.work_dir).expanduser().resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    corpus = Path(str(files("zerolm").joinpath("resources/tiny_corpus.txt")))
    tokenizer_path = train_tokenizer(
        [corpus],
        work_dir / "tokenizer",
        vocab_size=args.vocab_size,
        byte_fallback=True,
    )
    prepare_dataset(
        [corpus],
        tokenizer_path=tokenizer_path,
        output_dir=work_dir / "processed",
        validation_fraction=0.4,
    )
    tokenizer = Tokenizer(tokenizer_path)
    model = ZeroLM(model_preset(args.preset, vocab_size=tokenizer.vocab_size))
    device = select_device(args.device)
    config = TrainConfig(
        batch_size=2,
        learning_rate=1e-3,
        max_steps=args.max_steps,
        warmup_steps=0,
        eval_interval=max(1, args.max_steps),
        eval_batches=1,
        checkpoint_interval=max(1, args.max_steps),
        seed=1337,
    )
    result = train(
        model,
        train_tokens=load_tokens(work_dir / "processed/train.npy"),
        validation_tokens=load_tokens(work_dir / "processed/validation.npy"),
        config=config,
        device=device,
        output_dir=work_dir / "checkpoints",
        tokenizer_path=tokenizer_path,
    )
    prompt_ids = tokenizer.encode("语言模型", add_bos=True)
    generated = generate_token_ids(
        model,
        prompt_ids,
        max_new_tokens=16,
        temperature=0.8,
        top_k=40,
        eos_id=tokenizer.eos_id,
        generator=torch.Generator().manual_seed(1337),
    )
    _print_json(
        {
            "device": device.type,
            "parameter_count": model.num_parameters(),
            "step": result.step,
            "loss": result.loss,
            "validation_loss": result.validation_loss,
            "checkpoint": str(result.checkpoint_path),
            "generated_text": tokenizer.decode(generated),
        }
    )
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="zerolm")
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor = subparsers.add_parser("doctor", help="inspect local acceleration")
    doctor.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    doctor.set_defaults(handler=_doctor)

    tokenizer = subparsers.add_parser("tokenizer", help="train a tokenizer from scratch")
    tokenizer.add_argument("--input", nargs="+", required=True)
    tokenizer.add_argument("--output", default="artifacts/tokenizer")
    tokenizer.add_argument("--vocab-size", type=int, default=4096)
    tokenizer.add_argument("--model-type", choices=("bpe", "unigram", "char"), default="bpe")
    tokenizer.add_argument("--byte-fallback", action="store_true")
    tokenizer.set_defaults(handler=_tokenizer)

    prepare = subparsers.add_parser("prepare", help="encode a raw corpus")
    prepare.add_argument("--input", nargs="+", required=True)
    prepare.add_argument("--tokenizer", required=True)
    prepare.add_argument("--output-dir", default="data/processed")
    prepare.add_argument("--validation-fraction", type=float, default=0.05)
    prepare.set_defaults(handler=_prepare)

    reasoning_data = subparsers.add_parser(
        "reasoning-data",
        help="generate disjoint worked arithmetic data and benchmark",
    )
    reasoning_data.add_argument("--output-dir", default="data/reasoning")
    reasoning_data.add_argument("--training-examples", type=int, default=100_000)
    reasoning_data.add_argument("--validation-examples", type=int, default=2_000)
    reasoning_data.add_argument("--max-digits", type=int, default=3)
    reasoning_data.add_argument("--seed", type=int, default=1337)
    reasoning_data.set_defaults(handler=_reasoning_data)

    reasoning_eval = subparsers.add_parser(
        "reasoning-eval",
        help="score exact answers on arithmetic problems excluded from training",
    )
    reasoning_eval.add_argument("--checkpoint", required=True)
    reasoning_eval.add_argument("--tokenizer")
    reasoning_eval.add_argument("--benchmark", required=True)
    reasoning_eval.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    reasoning_eval.add_argument("--max-new-tokens", type=int, default=100)
    reasoning_eval.add_argument("--limit", type=int)
    reasoning_eval.set_defaults(handler=_reasoning_eval)

    solve = subparsers.add_parser(
        "solve",
        help="solve bounded exact arithmetic with a safe checked algorithm",
    )
    solve.add_argument("--expression", required=True)
    solve.set_defaults(handler=_solve)

    open_doctor = subparsers.add_parser(
        "open-doctor", help="inspect the optional local MLX assistant backend"
    )
    open_doctor.set_defaults(handler=_open_doctor)

    math_doctor = subparsers.add_parser(
        "math-doctor", help="inspect the optional local math backend"
    )
    math_doctor.set_defaults(handler=_math_doctor)

    open_generation = subparsers.add_parser(
        "open-generate", help="generate one reply with the local open-weight assistant"
    )
    open_generation.add_argument("--message", required=True)
    open_generation.add_argument("--model", default=DEFAULT_MODEL_ID)
    open_generation.add_argument("--adapter")
    open_generation.add_argument("--max-tokens", type=int, default=256)
    open_generation.add_argument("--temperature", type=float, default=0.2)
    open_generation.add_argument("--thinking", action="store_true")
    open_generation.add_argument("--stream", action="store_true")
    open_generation.add_argument("--history-file")
    open_generation.set_defaults(handler=_open_generate)

    vision_doctor = subparsers.add_parser(
        "vision-doctor", help="inspect the optional local MLX vision backend"
    )
    vision_doctor.set_defaults(handler=_vision_doctor)

    vision_generation = subparsers.add_parser(
        "vision-generate", help="answer one question about one local image"
    )
    vision_generation.add_argument("--image", required=True)
    vision_generation.add_argument("--message", default="请描述这张图片。")
    vision_generation.add_argument("--max-tokens", type=int, default=256)
    vision_generation.add_argument("--temperature", type=float, default=0.2)
    vision_generation.add_argument("--history-file")
    vision_generation.set_defaults(handler=_vision_generate)

    agent_run = subparsers.add_parser(
        "agent-run",
        help="run one read-only tool inside an explicitly selected workspace",
    )
    agent_run.add_argument("--workspace", required=True)
    agent_run.add_argument("--message", required=True)
    agent_run.add_argument("--answer", action="store_true")
    agent_run.add_argument("--max-tokens", type=int, default=384)
    agent_run.set_defaults(handler=_agent_run)

    wechat_scan = subparsers.add_parser(
        "wechat-scan",
        help="inspect a user-exported WeChat txt, md, or json file",
    )
    wechat_scan.add_argument("--input", required=True)
    wechat_scan.set_defaults(handler=_wechat_scan)

    mobile_serve = subparsers.add_parser(
        "mobile-serve",
        help="serve the local models to the paired ZeroLM iPhone app",
    )
    mobile_serve.add_argument("--host", default="127.0.0.1")
    mobile_serve.add_argument("--port", type=int, default=8765)
    mobile_serve.add_argument("--token")
    mobile_serve.set_defaults(handler=_mobile_serve)

    math_generation = subparsers.add_parser(
        "math-generate",
        help="use exact arithmetic first, then local DeepSeek for broader math",
    )
    math_generation.add_argument("--message", required=True)
    math_generation.add_argument("--max-tokens", type=int, default=512)
    math_generation.add_argument("--temperature", type=float, default=0.6)
    math_generation.add_argument("--history-file")
    math_generation.set_defaults(handler=_math_generate)

    open_lora_prepare = subparsers.add_parser(
        "open-lora-prepare", help="validate and split local chat JSONL for MLX-LM"
    )
    open_lora_prepare.add_argument("--input", required=True)
    open_lora_prepare.add_argument("--output-dir", default="artifacts/open-lora/data")
    open_lora_prepare.add_argument("--validation-count", type=int, default=1)
    open_lora_prepare.add_argument("--seed", type=int, default=1337)
    open_lora_prepare.add_argument(
        "--data-license", default="user-declared-local-data"
    )
    open_lora_prepare.set_defaults(handler=_open_lora_prepare)

    open_lora_train = subparsers.add_parser(
        "open-lora-train", help="run bounded local QLoRA training with MLX-LM"
    )
    open_lora_train.add_argument("--data-dir", default="artifacts/open-lora/data")
    open_lora_train.add_argument("--adapter-path", default="artifacts/open-lora/adapters")
    open_lora_train.add_argument("--model", default=DEFAULT_MODEL_ID)
    open_lora_train.add_argument("--iterations", type=int, default=100)
    open_lora_train.add_argument("--learning-rate", type=float, default=1e-5)
    open_lora_train.add_argument("--batch-size", type=int, default=1)
    open_lora_train.add_argument("--num-layers", type=int, default=4)
    open_lora_train.add_argument("--dry-run", action="store_true")
    open_lora_train.set_defaults(handler=_open_lora_train)

    training = subparsers.add_parser("train", help="pretrain from random weights")
    training.add_argument("--tokenizer", required=True)
    training.add_argument("--data-dir", default="data/processed")
    training.add_argument("--output-dir", default="artifacts/checkpoints")
    training.add_argument("--preset", choices=preset_names(), default="smoke")
    training.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    training.add_argument("--max-steps", type=int, default=1000)
    training.add_argument("--batch-size", type=int, default=16)
    training.add_argument("--learning-rate", type=float, default=3e-4)
    training.add_argument("--warmup-steps", type=int, default=50)
    training.add_argument("--gradient-accumulation-steps", type=int, default=1)
    training.add_argument("--eval-batches", type=int, default=10)
    training.add_argument("--eval-interval", type=int)
    training.add_argument("--checkpoint-interval", type=int)
    training.add_argument("--seed", type=int, default=1337)
    training.add_argument("--resume")
    training.set_defaults(handler=_train)

    generation = subparsers.add_parser("generate", help="generate from a checkpoint")
    generation.add_argument("--checkpoint", default="artifacts/checkpoints/final.pt")
    generation.add_argument("--tokenizer")
    generation.add_argument("--prompt", required=True)
    generation.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    generation.add_argument("--max-new-tokens", type=int, default=100)
    generation.add_argument("--temperature", type=float, default=0.8)
    generation.add_argument("--top-k", type=int, default=50)
    generation.add_argument("--seed", type=int, default=1337)
    generation.set_defaults(handler=_generate)

    chat = subparsers.add_parser("chat", help="chat interactively with a checkpoint")
    chat.add_argument("--checkpoint", default="artifacts/demo/checkpoints/final.pt")
    chat.add_argument("--tokenizer")
    chat.add_argument("--message", help="send one message instead of entering interactive mode")
    chat.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    chat.add_argument("--max-new-tokens", type=int, default=80)
    chat.add_argument("--temperature", type=float, default=0.8)
    chat.add_argument("--top-k", type=int, default=50)
    chat.add_argument("--seed", type=int, default=1337)
    chat.add_argument("--history-file")
    chat.set_defaults(handler=_chat)

    demo = subparsers.add_parser("demo", help="run a tiny end-to-end proof")
    demo.add_argument("--work-dir", default="artifacts/demo")
    demo.add_argument("--max-steps", type=int, default=2)
    demo.add_argument("--preset", choices=preset_names(), default="smoke")
    demo.add_argument("--vocab-size", type=int, default=1024)
    demo.add_argument("--device", choices=("auto", "mps", "cuda", "cpu"), default="auto")
    demo.set_defaults(handler=_demo)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return int(args.handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
