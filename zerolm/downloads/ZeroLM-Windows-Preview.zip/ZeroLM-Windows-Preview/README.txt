ZeroLM Windows 预览版
====================

这是可运行的 Windows 预览包，提供本地文字聊天。Mac 版中的照片、生图、
语音通话、微信窗口分析和本地 Agent 暂未移植到 Windows。

要求：
1. Windows 10 或 Windows 11
2. Python 3.11 或更新版本
3. Ollama：https://ollama.com/download/windows
4. 建议至少 8 GB 内存和 5 GB 可用磁盘空间

安装与启动：
1. 安装 Python 和 Ollama。
2. 双击“安装并启动.bat”。
3. 首次启动会下载 qwen2.5:3b 本地模型。

聊天内容只发送到本机的 Ollama 服务（127.0.0.1），不上传到酷越公司。
