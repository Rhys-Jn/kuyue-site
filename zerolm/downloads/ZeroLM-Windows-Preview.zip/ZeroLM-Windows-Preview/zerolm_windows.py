"""ZeroLM Windows preview UI backed by the user's local Ollama service."""

from __future__ import annotations

import json
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext
from urllib.error import URLError
from urllib.request import Request, urlopen

MODEL = "qwen2.5:3b"
ENDPOINT = "http://127.0.0.1:11434/api/chat"
SYSTEM = (
    "你是 ZeroLM，由酷越公司开发的本地 AI 助手。"
    "简洁、诚实地回答；不知道时明确说明，不声称拥有未提供的能力。"
)


class ZeroLMWindows:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("ZeroLM · Windows 预览版")
        self.root.geometry("900x680")
        self.root.minsize(640, 480)
        self.root.configure(bg="#0b0d0c")
        self.messages: list[dict[str, str]] = [
            {"role": "system", "content": SYSTEM}
        ]

        header = tk.Frame(self.root, bg="#111512", height=64)
        header.pack(fill=tk.X)
        tk.Label(
            header,
            text="ZeroLM",
            bg="#111512",
            fg="#f4f7f1",
            font=("Segoe UI", 18, "bold"),
        ).pack(side=tk.LEFT, padx=22, pady=16)
        self.status = tk.Label(
            header,
            text="本地 · 就绪",
            bg="#111512",
            fg="#d8ff3e",
            font=("Segoe UI", 10),
        )
        self.status.pack(side=tk.RIGHT, padx=22)

        self.chat = scrolledtext.ScrolledText(
            self.root,
            wrap=tk.WORD,
            bg="#0b0d0c",
            fg="#e9eee9",
            insertbackground="#d8ff3e",
            relief=tk.FLAT,
            padx=24,
            pady=22,
            font=("Microsoft YaHei UI", 11),
            state=tk.DISABLED,
        )
        self.chat.pack(fill=tk.BOTH, expand=True)
        self.chat.tag_configure("user", foreground="#8edfff", spacing1=16)
        self.chat.tag_configure("assistant", foreground="#f4f7f1", spacing1=16)

        composer = tk.Frame(self.root, bg="#111512", padx=18, pady=16)
        composer.pack(fill=tk.X)
        self.input = tk.Entry(
            composer,
            bg="#171c18",
            fg="#f4f7f1",
            insertbackground="#d8ff3e",
            relief=tk.FLAT,
            font=("Microsoft YaHei UI", 11),
        )
        self.input.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=11, padx=(0, 12))
        self.input.bind("<Return>", lambda _event: self.send())
        self.send_button = tk.Button(
            composer,
            text="发送",
            command=self.send,
            bg="#d8ff3e",
            fg="#111500",
            activebackground="#e5ff78",
            relief=tk.FLAT,
            padx=22,
            pady=10,
            font=("Microsoft YaHei UI", 10, "bold"),
        )
        self.send_button.pack(side=tk.RIGHT)
        self.append("assistant", "你好，我是 ZeroLM。这个 Windows 预览版在本机运行。")

    def append(self, role: str, text: str) -> None:
        self.chat.configure(state=tk.NORMAL)
        label = "你" if role == "user" else "ZeroLM"
        self.chat.insert(tk.END, f"{label}\n", role)
        self.chat.insert(tk.END, f"{text}\n")
        self.chat.configure(state=tk.DISABLED)
        self.chat.see(tk.END)

    def send(self) -> None:
        prompt = self.input.get().strip()
        if not prompt or self.send_button["state"] == tk.DISABLED:
            return
        self.input.delete(0, tk.END)
        self.append("user", prompt)
        self.messages.append({"role": "user", "content": prompt})
        self.send_button.configure(state=tk.DISABLED)
        self.status.configure(text="本地 · 正在回答", fg="#5dd8ff")
        threading.Thread(target=self.request_reply, daemon=True).start()

    def request_reply(self) -> None:
        payload = json.dumps(
            {"model": MODEL, "messages": self.messages[-20:], "stream": False}
        ).encode("utf-8")
        request = Request(
            ENDPOINT,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=180) as response:
                result = json.loads(response.read().decode("utf-8"))
            reply = result["message"]["content"].strip()
        except (URLError, TimeoutError, KeyError, json.JSONDecodeError) as error:
            self.root.after(
                0,
                lambda: messagebox.showerror(
                    "ZeroLM 无法回答",
                    f"请确认 Ollama 已启动并已安装 {MODEL}。\n\n{error}",
                ),
            )
            reply = "本地模型暂时无法回答，请检查 Ollama 后重试。"
        self.messages.append({"role": "assistant", "content": reply})
        self.root.after(0, lambda: self.finish_reply(reply))

    def finish_reply(self, reply: str) -> None:
        self.append("assistant", reply)
        self.status.configure(text="本地 · 就绪", fg="#d8ff3e")
        self.send_button.configure(state=tk.NORMAL)
        self.input.focus_set()

    def run(self) -> None:
        self.input.focus_set()
        self.root.mainloop()


if __name__ == "__main__":
    ZeroLMWindows().run()
