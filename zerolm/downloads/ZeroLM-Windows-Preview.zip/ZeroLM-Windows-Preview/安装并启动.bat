@echo off
chcp 65001 >nul
title ZeroLM Windows 预览版

where python >nul 2>nul
if errorlevel 1 (
  echo 未找到 Python 3.11 或更新版本。
  echo 请前往 https://www.python.org/downloads/windows/ 安装后重试。
  pause
  exit /b 1
)

where ollama >nul 2>nul
if errorlevel 1 (
  echo 未找到 Ollama。
  echo 请前往 https://ollama.com/download/windows 安装后重试。
  pause
  exit /b 1
)

echo 正在准备 ZeroLM 本地模型，首次使用需要下载约 2 GB...
ollama pull qwen2.5:3b
if errorlevel 1 (
  echo 模型下载失败，请检查网络后重试。
  pause
  exit /b 1
)

python "%~dp0zerolm_windows.py"
